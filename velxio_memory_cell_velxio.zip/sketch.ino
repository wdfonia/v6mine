#include <Arduino.h>

// ===== Pin assignment (Arduino UNO) =====
// Four memory LEDs are arranged LEFT -> RIGHT as bit 3,2,1,0 of the shown nibble.
// All four pins support PWM, so stored '1' can be 50% brightness and the active bit 100%.
const uint8_t MEM_LED_PINS[4] = {3, 5, 6, 9};

// Group indicators: IND_MSB IND_LSB = 00, 01, 10, 11
const uint8_t IND_MSB_PIN = 10;
const uint8_t IND_LSB_PIN = 11;

// KY-040 rotary encoder
const uint8_t ENC_CLK_PIN = 2;
const uint8_t ENC_DT_PIN  = 4;

// Two separate push buttons (wired to GND, INPUT_PULLUP)
const uint8_t BTN1_PIN = 7;  // next 4-bit group
const uint8_t BTN2_PIN = 8;  // toggle selected bit

const uint8_t BRIGHTNESS_ONE    = 128; // ~50%
const uint8_t BRIGHTNESS_ACTIVE = 255; // 100%

// Initial 16-bit memory value from the task: 1001001001000₂
// As a 16-bit number: 0001 0010 0100 1000₂ = 0x1248 = 4680.
uint16_t memoryCell = 0b0001001001001000;

// 0 -> bits 0..3, 1 -> 4..7, 2 -> 8..11, 3 -> 12..15
uint8_t currentGroup = 0;

// Physical position in the row: 0=left, 3=right.
uint8_t cursorPos = 0;
bool activeVisible = false;

// Encoder state
int lastEncoderCLK = HIGH;
unsigned long lastEncoderStepMs = 0;

// Long press of both buttons
bool comboSession = false;
bool comboTriggered = false;
unsigned long comboStartMs = 0;

// ---------- Debounced button ----------
struct DebouncedButton {
  uint8_t pin = 0;
  bool rawPressed = false;
  bool stablePressed = false;
  bool pressedEdge = false;
  bool releasedEdge = false;
  unsigned long rawChangedAt = 0;

  void begin(uint8_t p) {
    pin = p;
    pinMode(pin, INPUT_PULLUP);
    rawPressed = (digitalRead(pin) == LOW);
    stablePressed = rawPressed;
    rawChangedAt = millis();
  }

  void update(unsigned long now) {
    pressedEdge = false;
    releasedEdge = false;

    bool r = (digitalRead(pin) == LOW);
    if (r != rawPressed) {
      rawPressed = r;
      rawChangedAt = now;
    }

    if (rawPressed != stablePressed && (now - rawChangedAt) >= 25) {
      stablePressed = rawPressed;
      if (stablePressed) pressedEdge = true;
      else releasedEdge = true;
    }
  }
};

DebouncedButton button1;
DebouncedButton button2;

// Return absolute memory bit number for a physical LED position.
// Row is shown in conventional binary order: left is the most significant bit of the nibble.
uint8_t bitNumberForPos(uint8_t pos) {
  return currentGroup * 4 + (3 - pos);
}

void renderIndicators() {
  digitalWrite(IND_MSB_PIN, (currentGroup & 0b10) ? HIGH : LOW);
  digitalWrite(IND_LSB_PIN, (currentGroup & 0b01) ? HIGH : LOW);
}

void renderMemoryLeds() {
  for (uint8_t pos = 0; pos < 4; ++pos) {
    uint8_t bitNo = bitNumberForPos(pos);

    if (activeVisible && pos == cursorPos) {
      // Active bit is highlighted at 100%, regardless of its stored value.
      analogWrite(MEM_LED_PINS[pos], BRIGHTNESS_ACTIVE);
    } else {
      bool value = (memoryCell >> bitNo) & 1U;
      analogWrite(MEM_LED_PINS[pos], value ? BRIGHTNESS_ONE : 0);
    }
  }
}

void renderAll() {
  renderIndicators();
  renderMemoryLeds();
}

void printBinary16(uint16_t value) {
  for (int8_t b = 15; b >= 0; --b) {
    Serial.print((value >> b) & 1U);
  }
}

void printGroupCode() {
  Serial.print((currentGroup >> 1) & 1U);
  Serial.print(currentGroup & 1U);
}

void printVisibleNibble() {
  for (uint8_t pos = 0; pos < 4; ++pos) {
    uint8_t bitNo = bitNumberForPos(pos);
    Serial.print((memoryCell >> bitNo) & 1U);
  }
}

void printState(const char *reason) {
  Serial.println();
  Serial.print(F("=== "));
  Serial.print(reason);
  Serial.println(F(" ==="));

  Serial.print(F("GROUP: "));
  printGroupCode();
  Serial.print(F("  (bits "));
  Serial.print(currentGroup * 4);
  Serial.print(F(".."));
  Serial.print(currentGroup * 4 + 3);
  Serial.println(F(")"));

  Serial.print(F("VISIBLE [MSB..LSB]: "));
  printVisibleNibble();
  Serial.println();

  Serial.print(F("BIN16: "));
  printBinary16(memoryCell);
  Serial.println();

  Serial.print(F("DEC:   "));
  Serial.println((unsigned int)memoryCell);
}

void startupLedTest() {
  // All four row LEDs turn on one after another every 500 ms,
  // then all four are switched off together.
  for (uint8_t i = 0; i < 4; ++i) {
    analogWrite(MEM_LED_PINS[i], BRIGHTNESS_ACTIVE);
    delay(500);
  }

  for (uint8_t i = 0; i < 4; ++i) {
    analogWrite(MEM_LED_PINS[i], 0);
  }
}

void moveCursor(int8_t direction) {
  int8_t next = (int8_t)cursorPos + direction;
  if (next < 0) next = 3;
  if (next > 3) next = 0;
  cursorPos = (uint8_t)next;
  activeVisible = true;

  renderMemoryLeds();

  Serial.print(F("Active bit: "));
  Serial.print(bitNumberForPos(cursorPos));
  Serial.print(F(" (row position "));
  Serial.print(cursorPos + 1);
  Serial.println(F("/4)"));
}

void handleEncoder() {
  int clk = digitalRead(ENC_CLK_PIN);

  // One action per falling edge of CLK.
  if (lastEncoderCLK == HIGH && clk == LOW) {
    unsigned long now = millis();
    if (now - lastEncoderStepMs >= 3) {
      // For KY-040 in Wokwi/Velxio:
      // clockwise: CLK falls first while DT is HIGH.
      int8_t direction = (digitalRead(ENC_DT_PIN) == HIGH) ? +1 : -1;
      moveCursor(direction);
      lastEncoderStepMs = now;
    }
  }

  lastEncoderCLK = clk;
}

void nextGroup() {
  currentGroup = (currentGroup + 1) & 0x03;
  activeVisible = false;
  renderAll();
  printState("BUTTON 1: NEXT GROUP");
}

void toggleActiveBit() {
  if (!activeVisible) {
    Serial.println(F("Button 2 ignored: rotate encoder first to select an active bit."));
    return;
  }

  uint8_t bitNo = bitNumberForPos(cursorPos);
  memoryCell ^= (uint16_t)(1U << bitNo);

  // The 100% active highlight disappears until the next encoder turn.
  activeVisible = false;
  renderMemoryLeds();
  printState("BUTTON 2: BIT TOGGLED");
}

void invertAllBits() {
  memoryCell ^= 0xFFFFU;
  activeVisible = false;
  renderAll();
  printState("BOTH BUTTONS 2s: ALL 16 BITS INVERTED");
}

void handleButtons(unsigned long now) {
  button1.update(now);
  button2.update(now);

  // If both are held, suppress normal single-button actions for the whole combo session.
  if (button1.stablePressed && button2.stablePressed) {
    if (!comboSession) {
      comboSession = true;
      comboTriggered = false;
      comboStartMs = now;
    }

    if (!comboTriggered && (now - comboStartMs >= 2000UL)) {
      invertAllBits();
      comboTriggered = true;
    }
    return;
  }

  if (comboSession) {
    // Keep suppressing short-click actions until BOTH buttons have been released.
    if (!button1.stablePressed && !button2.stablePressed) {
      comboSession = false;
      comboTriggered = false;
    }
    return;
  }

  // Single-button actions are performed on release: this avoids accidental actions
  // when the user intends to press both buttons together.
  if (button1.releasedEdge) {
    nextGroup();
  }

  if (button2.releasedEdge) {
    toggleActiveBit();
  }
}

void setup() {
  Serial.begin(115200);

  for (uint8_t i = 0; i < 4; ++i) {
    pinMode(MEM_LED_PINS[i], OUTPUT);
    analogWrite(MEM_LED_PINS[i], 0);
  }

  pinMode(IND_MSB_PIN, OUTPUT);
  pinMode(IND_LSB_PIN, OUTPUT);
  digitalWrite(IND_MSB_PIN, LOW);
  digitalWrite(IND_LSB_PIN, LOW);

  pinMode(ENC_CLK_PIN, INPUT_PULLUP);
  pinMode(ENC_DT_PIN, INPUT_PULLUP);

  button1.begin(BTN1_PIN);
  button2.begin(BTN2_PIN);

  Serial.println(F("16-bit memory controller - practical tour"));
  Serial.println(F("Power-on LED test..."));
  startupLedTest();

  currentGroup = 0;
  activeVisible = false;
  renderAll();

  lastEncoderCLK = digitalRead(ENC_CLK_PIN);

  printState("READY");
}

void loop() {
  unsigned long now = millis();

  handleButtons(now);
  handleEncoder();
}
