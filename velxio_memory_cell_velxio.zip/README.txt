Velxio / Wokwi-importable project for the 2026-2027 school-stage robotics practical task.

Pins (Arduino UNO):
D3  -> row LED, leftmost (bit 3/7/11/15), PWM
D5  -> row LED (bit 2/6/10/14), PWM
D6  -> row LED (bit 1/5/9/13), PWM
D9  -> row LED, rightmost (bit 0/4/8/12), PWM
D10 -> group indicator MSB
D11 -> group indicator LSB
D2  -> KY-040 CLK
D4  -> KY-040 DT
D7  -> Button 1 (next group)
D8  -> Button 2 (toggle active bit)

Initial memory: 0001001001001000b = 4680.

Button 1 cycles groups 00 -> 01 -> 10 -> 11 -> 00.
Rotate encoder to move the 100% bright active bit.
Button 2 toggles that bit; active highlight then disappears.
Hold both buttons for 2 seconds to invert all 16 bits.
Serial monitor prints BIN16 and DEC.
