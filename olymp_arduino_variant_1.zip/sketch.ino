const byte leds[4]={3,5,6,9};
const byte ind[2]={10,11};
const byte encA=2;
const byte encB=4;
const byte btn1=7;
const byte btn2=8;

uint16_t memoryCell=0b0001001001001000;
byte part=0;
byte pos=0;
bool active=false;
volatile int a=0;

int raw1=HIGH,raw2=HIGH;
int st1=HIGH,st2=HIGH;
unsigned long db1=0,db2=0;
unsigned long bothTime=0;
bool pairNow=false,pairDone=false;
bool pair1=false,pair2=false;

void encTick(){
 if(digitalRead(encB)==HIGH) a++;
 else a--;
}

void printCell(){
 Serial.print("pamyat: ");
 for(int i=15;i>=0;i--) Serial.print(bitRead(memoryCell,i));
 Serial.print(" | desyatichnoe: ");
 Serial.println(memoryCell);
}

void draw(){
 digitalWrite(ind[0],(part>>1)&1);
 digitalWrite(ind[1],part&1);
 for(byte i=0;i<4;i++){
  byte n=part*4+i;
  int x=bitRead(memoryCell,n)?128:0;
  if(active && i==pos) x=255;
  analogWrite(leds[i],x);
 }
}

void moveBit(int d){
 if(!active){
  active=true;
  pos=d>0?0:3;
 }else{
  int n=(int)pos+d;
  if(n<0)n=0;
  if(n>3)n=3;
  pos=n;
 }
 draw();
 Serial.print("aktivnyi bit: ");
 Serial.println(part*4+pos);
}

void encoderRead(){
 noInterrupts();
 int d=a;
 a=0;
 interrupts();
 while(d>0){moveBit(1);d--;}
 while(d<0){moveBit(-1);d++;}
}

void keys(){
 unsigned long t=millis();
 int x=digitalRead(btn1);
 int y=digitalRead(btn2);
 bool c1=false,c2=false;

 if(x!=raw1){raw1=x;db1=t;}
 if(y!=raw2){raw2=y;db2=t;}
 if(t-db1>25 && st1!=raw1){st1=raw1;c1=true;}
 if(t-db2>25 && st2!=raw2){st2=raw2;c2=true;}

 if(st1==LOW && st2==LOW){
  pair1=true;pair2=true;
  if(!pairNow){pairNow=true;bothTime=t;pairDone=false;}
  if(!pairDone && t-bothTime>=2000){
   memoryCell=~memoryCell;
   active=false;
   pairDone=true;
   draw();
   Serial.println("vse bity invertirovany");
   printCell();
  }
 }else pairNow=false;

 if(c1 && st1==HIGH){
  if(!pair1){
   part=(part+1)&3;
   active=false;
   draw();
   Serial.print("razryady: ");
   Serial.print(part*4);
   Serial.print("-");
   Serial.println(part*4+3);
   printCell();
  }
  pair1=false;
 }

 if(c2 && st2==HIGH){
  if(!pair2 && active){
   byte n=part*4+pos;
   memoryCell^=(uint16_t)1<<n;
   active=false;
   draw();
   Serial.print("bit izmenen: ");
   Serial.println(n);
   printCell();
  }
  pair2=false;
 }
}

void setup(){
 Serial.begin(115200);
 for(byte i=0;i<4;i++) pinMode(leds[i],OUTPUT);
 for(byte i=0;i<2;i++) pinMode(ind[i],OUTPUT);
 pinMode(encA,INPUT);
 pinMode(encB,INPUT);
 pinMode(btn1,INPUT_PULLUP);
 pinMode(btn2,INPUT_PULLUP);
 attachInterrupt(digitalPinToInterrupt(encA),encTick,FALLING);

 digitalWrite(ind[0],LOW);
 digitalWrite(ind[1],LOW);
 for(byte i=0;i<4;i++){
  analogWrite(leds[i],255);
  delay(500);
 }
 for(byte i=0;i<4;i++) analogWrite(leds[i],0);
 delay(120);
 draw();
 Serial.println("start");
 printCell();
}

void loop(){
 encoderRead();
 keys();
}
