"""Offline host tests for the ORIGINAL sketch and diagram. No pip packages needed.

Run: python verification/run_tests.py
Requires Python 3.8+ and a C++11 compiler (g++ or clang++) in PATH.
This is a logic test, NOT an AVR compilation or a Velxio simulation.
"""
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent.parent


def validate_diagram():
    diagram = json.loads((ROOT / 'diagram.json').read_text(encoding='utf-8'))
    assert diagram['version'] == 1
    parts = {part['id']: part for part in diagram['parts']}
    assert len(parts) == len(diagram['parts']), 'Duplicate component IDs'
    allowed = {
        'wokwi-arduino-uno', 'wokwi-breadboard', 'wokwi-led',
        'wokwi-resistor', 'wokwi-ky-040', 'wokwi-pushbutton', 'wokwi-text'
    }
    assert all(part['type'] in allowed for part in parts.values())
    for type_, expected in [('wokwi-arduino-uno', 1), ('wokwi-breadboard', 1),
                            ('wokwi-led', 6), ('wokwi-resistor', 6),
                            ('wokwi-ky-040', 1), ('wokwi-pushbutton', 2)]:
        assert sum(p['type'] == type_ for p in parts.values()) == expected, type_

    def valid_pin(endpoint):
        part_id, pin = endpoint.split(':', 1)
        assert part_id in parts, f'Unknown component: {endpoint}'
        type_ = parts[part_id]['type']
        if type_ == 'wokwi-breadboard':
            return bool(re.fullmatch(r'(?:[tb][np]\.(?:[1-9]|[1-4]\d|50)|(?:[1-9]|[1-5]\d|6[0-3])(?:t\.[a-e]|b\.[f-j]))', pin))
        if type_ == 'wokwi-arduino-uno':
            return pin in [str(i) for i in range(14)] + ['5V','3.3V','GND.1','GND.2','GND.3']
        return pin in {
            'wokwi-led': ['A','C'], 'wokwi-resistor': ['1','2'],
            'wokwi-ky-040': ['CLK','DT','SW','VCC','GND'],
            'wokwi-pushbutton': ['1.l','1.r','2.l','2.r'],
        }.get(type_, [])

    parent = {}
    def find(x):
        parent.setdefault(x, x)
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]
    def join(a, b):
        parent[find(a)] = find(b)
    def connected(a, b):
        return find(a) == find(b)

    # Breadboard strips and power rails conduct; opposite banks do not.
    for rail in ['tp','tn','bp','bn']:
        for i in range(2, 51):
            join(f'breadboard:{rail}.1', f'breadboard:{rail}.{i}')
    for col in range(1, 64):
        for bank, holes in [('t','abcde'),('b','fghij')]:
            for hole in holes[1:]:
                join(f'breadboard:{col}{bank}.{holes[0]}', f'breadboard:{col}{bank}.{hole}')
    for button in ['page_button','edit_button']:
        join(button+':1.l', button+':1.r')
        join(button+':2.l', button+':2.r')

    for wire in diagram['connections']:
        assert len(wire) == 4
        a, b, color, route = wire
        assert valid_pin(a) and valid_pin(b), f'Invalid pin: {a} -> {b}'
        assert isinstance(color,str) and isinstance(route,list)
        join(a,b)

    assert not connected('uno:5V','uno:GND.1'), 'Power short circuit'
    led_ids = ['memory_led_3','memory_led_2','memory_led_1','memory_led_0','page_msb','page_lsb']
    gpio_pins = [5,6,9,10,11,12]
    for led, pin in zip(led_ids, gpio_pins):
        resistor = 'resistor_' + led
        assert parts[resistor]['attrs']['value'] == '330'
        assert connected(f'uno:{pin}', f'{resistor}:2'), f'Wrong drive for {led}'
        assert connected(f'{resistor}:1', f'{led}:A'), f'Missing series resistor for {led}'
        assert connected(f'{led}:C', 'uno:GND.1'), f'Cathode not grounded: {led}'
        assert not connected(f'{resistor}:1',f'{resistor}:2'), f'Resistor bypassed: {led}'
        assert not connected(f'uno:{pin}','uno:GND.1'), f'Shorted GPIO: {pin}'
        assert not connected(f'uno:{pin}','uno:5V'), f'Shorted GPIO: {pin}'
    for a in gpio_pins + [2,3,7,8]:
        for b in gpio_pins + [2,3,7,8]:
            if a != b:
                assert not connected(f'uno:{a}', f'uno:{b}'), f'GPIO short: {a} <-> {b}'
    for signal, pin in [('CLK',2),('DT',3)]:
        assert connected('encoder:'+signal, 'uno:'+str(pin))
    assert connected('encoder:VCC', 'uno:5V')
    assert connected('encoder:GND', 'uno:GND.1')
    for name, pin in [('page_button',7),('edit_button',8)]:
        assert connected(name+':1.l','uno:'+str(pin))
        assert connected(name+':2.r','uno:GND.1')
        assert not connected(name+':1.l',name+':2.r'), f'Button permanently closed: {name}'
    print('PASS | Diagram: component counts, pin names, breadboard nets, series resistors, no GPIO/power shorts', flush=True)


def main():
    validate_diagram()
    compiler = shutil.which('g++') or shutil.which('clang++')
    if compiler is None:
        raise RuntimeError('Install g++ or clang++ and add it to PATH to run the C++ logic tests.')
    with tempfile.TemporaryDirectory(prefix='memory16_tests_') as directory:
        directory = Path(directory)
        shutil.copy2(ROOT/'sketch.ino', directory/'sketch.ino')
        shutil.copy2(ROOT/'verification'/'Arduino.h.txt', directory/'Arduino.h')
        shutil.copy2(ROOT/'verification'/'logic_test.cpp.txt', directory/'logic_test.cpp')
        executable = directory / ('logic_test.exe' if sys.platform == 'win32' else 'logic_test')
        subprocess.run([compiler, '-std=c++11', '-Wall', '-Wextra', '-Werror', '-pedantic',
                        '-O2', '-I', str(directory), str(directory/'logic_test.cpp'),
                        '-o', str(executable)], check=True)
        subprocess.run([str(executable)], check=True)
    print('Host-only tests finished. AVR build and real/simulator hardware still need to be checked.')

if __name__ == '__main__':
    try:
        main()
    except (AssertionError, RuntimeError, OSError, subprocess.CalledProcessError) as error:
        print('FAIL:', error, file=sys.stderr)
        sys.exit(1)
