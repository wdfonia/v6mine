const byte bitLed[4]={5,6,9,10};
const byte pageLed[2]={11,12};
const byte eA=3,eB=4;
const byte kNext=7,kSet=8;

uint16_t data16=0x1248;
byte page=0;
byte cur=0;
bool chosen=false;
volatile int b=0;

int rA=HIGH,rB=HIGH,sA=HIGH,sB=HIGH;
unsigned long tA=0,tB=0,twoStart=0;
bool together=false,doneTwo=false;
bool lockA=false,lockB=false;

void encoder(){
 if(digitalRead(eB)) b++;
 else b--;
}

void terminal(){
 Serial.print("dvoichnoe: ");
 for(int i=15;i>=0;i--) Serial.print((data16>>i)&1);
 Serial.print(" | chislo: ");
 Serial.println(data16);
}

void screenOut(){
 digitalWrite(pageLed[0],page&2);
 digitalWrite(pageLed[1],page&1);
 for(byte i=0;i<4;i++){
  byte q=page*4+i;
  byte p=((data16>>q)&1)?128:0;
  if(chosen && cur==i)p=255;
  analogWrite(bitLed[i],p);
 }
}

void shiftCur(int d){
 if(!chosen){
  chosen=true;
  cur=d>0?0:3;
 }else{
  int q=cur+d;
  if(q<0)q=0;
  if(q>3)q=3;
  cur=q;
 }
 screenOut();
 Serial.print("vybran bit: ");
 Serial.println(page*4+cur);
}

void getEncoder(){
 noInterrupts();
 int c=b;
 b=0;
 interrupts();
 if(c>0) while(c-- > 0) shiftCur(1);
 if(c<0) while(c++ < 0) shiftCur(-1);
}

void buttonWork(){
 unsigned long now=millis();
 int a=digitalRead(kNext);
 int d=digitalRead(kSet);
 bool u=false,v=false;

 if(a!=rA){rA=a;tA=now;}
 if(d!=rB){rB=d;tB=now;}
 if(now-tA>=30 && sA!=rA){sA=rA;u=true;}
 if(now-tB>=30 && sB!=rB){sB=rB;v=true;}

 if(sA==LOW && sB==LOW){
  lockA=true;lockB=true;
  if(!together){together=true;twoStart=now;doneTwo=false;}
  if(!doneTwo && now-twoStart>=2000){
   data16^=0xFFFF;
   chosen=false;
   doneTwo=true;
   screenOut();
   Serial.println("pamyat invertirovana");
   terminal();
  }
 }else together=false;

 if(u && sA==HIGH){
  if(!lockA){
   page++;
   if(page>3)page=0;
   chosen=false;
   screenOut();
   Serial.print("okno: ");
   Serial.print(page*4);
   Serial.print("-");
   Serial.println(page*4+3);
   terminal();
  }
  lockA=false;
 }

 if(v && sB==HIGH){
  if(!lockB && chosen){
   byte q=page*4+cur;
   bitWrite(data16,q,!bitRead(data16,q));
   chosen=false;
   screenOut();
   Serial.print("izmenen bit: ");
   Serial.println(q);
   terminal();
  }
  lockB=false;
 }
}

void setup(){
 Serial.begin(115200);
 for(byte i=0;i<4;i++)pinMode(bitLed[i],OUTPUT);
 for(byte i=0;i<2;i++)pinMode(pageLed[i],OUTPUT);
 pinMode(eA,INPUT);
 pinMode(eB,INPUT);
 pinMode(kNext,INPUT_PULLUP);
 pinMode(kSet,INPUT_PULLUP);
 attachInterrupt(digitalPinToInterrupt(eA),encoder,FALLING);

 for(byte i=0;i<4;i++){
  analogWrite(bitLed[i],255);
  delay(500);
 }
 for(byte i=0;i<4;i++)analogWrite(bitLed[i],0);
 digitalWrite(pageLed[0],LOW);
 digitalWrite(pageLed[1],LOW);
 delay(100);
 screenOut();
 Serial.println("gotovo");
 terminal();
}

void loop(){
 getEncoder();
 buttonWork();
}
