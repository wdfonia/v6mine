// Уровень 3: визуализатор битовых операций.
// A = A0>>2, B = A1>>2. B1/B2 листают операцию, B3 замораживает значения.
// LED D2...D9 показывают результат. Названия и числа выводятся в Serial.

const byte BTN_PREV = 10;
const byte BTN_NEXT = 11;
const byte BTN_FREEZE = 12;

struct Button {
  byte pin;
  bool stable;
  bool lastReading;
  unsigned long changedAt;
};

bool buttonPressed(Button &button);

Button prevButton = {BTN_PREV, HIGH, HIGH, 0};
Button nextButton = {BTN_NEXT, HIGH, HIGH, 0};
Button freezeButton = {BTN_FREEZE, HIGH, HIGH, 0};

const byte OP_COUNT = 10;
byte operation = 0;
byte a = 0;
byte b = 0;
bool frozen = false;
unsigned long lastPrint = 0;

bool buttonPressed(Button &button) {
  bool reading = digitalRead(button.pin);
  if (reading != button.lastReading) {
    button.lastReading = reading;
    button.changedAt = millis();
  }
  if (millis() - button.changedAt >= 25 && reading != button.stable) {
    button.stable = reading;
    return button.stable == LOW;
  }
  return false;
}

void ledsBeginFast() {
  DDRD |= 0b11111100;
  DDRB |= 0b00000011;
}

void showByteFast(byte value) {
  PORTD = (PORTD & 0b00000011) | ((value & 0b00111111) << 2);
  PORTB = (PORTB & 0b11111100) | ((value >> 6) & 0b00000011);
}

byte rotateLeft8(byte x) {
  return (byte)((x << 1) | (x >> 7));
}

byte rotateRight8(byte x) {
  return (byte)((x >> 1) | (x << 7));
}

byte calculate(byte x, byte y, byte op) {
  switch (op) {
    case 0: return x;
    case 1: return (byte)~x;
    case 2: return x & y;
    case 3: return x | y;
    case 4: return x ^ y;
    case 5: return (byte)(x << 1);
    case 6: return x >> 1;
    case 7: return rotateLeft8(x);
    case 8: return rotateRight8(x);
    case 9: return x ^ (x >> 1); // двоичное число -> код Грея
  }
  return 0;
}

const __FlashStringHelper *operationName(byte op) {
  switch (op) {
    case 0: return F("A");
    case 1: return F("NOT A");
    case 2: return F("A AND B");
    case 3: return F("A OR B");
    case 4: return F("A XOR B");
    case 5: return F("A << 1");
    case 6: return F("A >> 1");
    case 7: return F("ROL A");
    case 8: return F("ROR A");
    case 9: return F("GRAY(A)");
  }
  return F("?");
}

void printBits(byte x) {
  for (int i = 7; i >= 0; --i) Serial.print(bitRead(x, i));
}

void setup() {
  ledsBeginFast();
  pinMode(BTN_PREV, INPUT_PULLUP);
  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(BTN_FREEZE, INPUT_PULLUP);
  Serial.begin(115200);
}

void loop() {
  bool forcePrint = false;
  if (buttonPressed(prevButton)) {
    operation = (operation + OP_COUNT - 1) % OP_COUNT;
    forcePrint = true;
  }
  if (buttonPressed(nextButton)) {
    operation = (operation + 1) % OP_COUNT;
    forcePrint = true;
  }
  if (buttonPressed(freezeButton)) {
    frozen = !frozen;
    forcePrint = true;
  }

  if (!frozen) {
    a = analogRead(A0) >> 2;
    b = analogRead(A1) >> 2;
  }

  byte result = calculate(a, b, operation);
  showByteFast(result);

  if (forcePrint || millis() - lastPrint >= 300) {
    lastPrint = millis();
    Serial.print(frozen ? F("[FROZEN] ") : F("[LIVE] "));
    Serial.print(operationName(operation));
    Serial.print(F(" | A=")); printBits(a);
    Serial.print(F(" B=")); printBits(b);
    Serial.print(F(" -> ")); printBits(result);
    Serial.print(F(" (")); Serial.print(result); Serial.println(')');
  }
}
