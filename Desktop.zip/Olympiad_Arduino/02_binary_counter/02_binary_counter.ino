// Уровень 2: восьмибитный счётчик.
// B1 (D10) +1, B2 (D11) -1, B3 (D12) авто/стоп. A0 задаёт скорость.
// LED D2...D9 показывают биты 0...7 числа.

const byte BTN_UP = 10;
const byte BTN_DOWN = 11;
const byte BTN_AUTO = 12;
const byte POT_SPEED = A0;

struct Button {
  byte pin;
  bool stable;
  bool lastReading;
  unsigned long changedAt;
};

bool buttonPressed(Button &b);

Button upButton = {BTN_UP, HIGH, HIGH, 0};
Button downButton = {BTN_DOWN, HIGH, HIGH, 0};
Button autoButton = {BTN_AUTO, HIGH, HIGH, 0};

byte counter = 0;
bool autoMode = false;
unsigned long lastStep = 0;

bool buttonPressed(Button &b) {
  bool reading = digitalRead(b.pin);
  if (reading != b.lastReading) {
    b.lastReading = reading;
    b.changedAt = millis();
  }
  if (millis() - b.changedAt >= 25 && reading != b.stable) {
    b.stable = reading;
    return b.stable == LOW;
  }
  return false;
}

void ledsBeginFast() {
  DDRD |= 0b11111100; // D2...D7
  DDRB |= 0b00000011; // D8...D9
}

void showByteFast(byte value) {
  PORTD = (PORTD & 0b00000011) | ((value & 0b00111111) << 2);
  PORTB = (PORTB & 0b11111100) | ((value >> 6) & 0b00000011);
}

void printByte(byte value) {
  Serial.print(value);
  Serial.print(F(" = 0b"));
  for (int i = 7; i >= 0; --i) Serial.print(bitRead(value, i));
  Serial.println();
}

void setup() {
  ledsBeginFast();
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_AUTO, INPUT_PULLUP);
  Serial.begin(115200);
  showByteFast(counter);
  printByte(counter);
}

void loop() {
  bool changed = false;

  if (buttonPressed(upButton)) {
    ++counter; // byte после 255 автоматически станет 0
    changed = true;
  }
  if (buttonPressed(downButton)) {
    --counter; // byte после 0 автоматически станет 255
    changed = true;
  }
  if (buttonPressed(autoButton)) {
    autoMode = !autoMode;
    lastStep = millis();
    Serial.println(autoMode ? F("AUTO") : F("MANUAL"));
  }

  unsigned long interval = map(analogRead(POT_SPEED), 0, 1023, 30, 1000);
  if (autoMode && millis() - lastStep >= interval) {
    lastStep = millis();
    ++counter;
    changed = true;
  }

  if (changed) {
    showByteFast(counter);
    printByte(counter);
  }
}
