// Уровень 3: измеритель реакции на конечном автомате без delay().
// Нажми D10, отпусти, дождись загорания всех LED и нажми снова.
// Раннее нажатие считается фальстартом. Результат — в Serial (115200).

const byte REACTION_BUTTON = 10;

enum GameState { IDLE, WAIT_RELEASE, RANDOM_WAIT, SIGNAL_ON, SHOW_RESULT, FALSE_START };
GameState state = IDLE;

bool stable = HIGH;
bool lastReading = HIGH;
unsigned long changedAt = 0;
unsigned long stateStarted = 0;
unsigned long signalAt = 0;
unsigned long randomDelayMs = 0;

void ledsBeginFast() {
  DDRD |= 0b11111100;
  DDRB |= 0b00000011;
}

void showByteFast(byte value) {
  PORTD = (PORTD & 0b00000011) | ((value & 0b00111111) << 2);
  PORTB = (PORTB & 0b11111100) | ((value >> 6) & 0b00000011);
}

// Возвращает: 1 — нажатие, -1 — отпускание, 0 — без события.
int buttonEvent() {
  bool reading = digitalRead(REACTION_BUTTON);
  if (reading != lastReading) {
    lastReading = reading;
    changedAt = millis();
  }
  if (millis() - changedAt >= 25 && reading != stable) {
    stable = reading;
    return stable == LOW ? 1 : -1;
  }
  return 0;
}

void startGame() {
  showByteFast(0);
  state = WAIT_RELEASE;
  stateStarted = millis();
  Serial.println(F("Отпусти кнопку и жди сигнал..."));
}

void setup() {
  ledsBeginFast();
  pinMode(REACTION_BUTTON, INPUT_PULLUP);
  Serial.begin(115200);
  randomSeed(analogRead(A1) ^ micros());
  Serial.println(F("Нажми кнопку D10, чтобы начать."));
}

void loop() {
  int event = buttonEvent();

  switch (state) {
    case IDLE:
      // Мягкое мигание не нужно: ждём одно нажатие.
      if (event == 1) startGame();
      break;

    case WAIT_RELEASE:
      if (event == -1) {
        randomDelayMs = random(1000, 5001);
        stateStarted = millis();
        state = RANDOM_WAIT;
      }
      break;

    case RANDOM_WAIT:
      if (event == 1) {
        showByteFast(0b10101010);
        stateStarted = millis();
        state = FALSE_START;
        Serial.println(F("ФАЛЬСТАРТ!"));
      } else if (millis() - stateStarted >= randomDelayMs) {
        showByteFast(0xFF);
        signalAt = millis();
        state = SIGNAL_ON;
      }
      break;

    case SIGNAL_ON:
      if (event == 1) {
        unsigned long reaction = millis() - signalAt;
        showByteFast((byte)reaction); // младшие 8 бит результата
        Serial.print(F("Реакция: "));
        Serial.print(reaction);
        Serial.println(F(" мс"));
        stateStarted = millis();
        state = SHOW_RESULT;
      }
      break;

    case SHOW_RESULT:
      if (millis() - stateStarted >= 2000 && stable == HIGH) {
        showByteFast(0);
        state = IDLE;
        Serial.println(F("Нажми для новой попытки."));
      }
      break;

    case FALSE_START:
      if (millis() - stateStarted >= 1200 && stable == HIGH) {
        showByteFast(0);
        state = IDLE;
        Serial.println(F("Нажми для новой попытки."));
      }
      break;
  }
}

