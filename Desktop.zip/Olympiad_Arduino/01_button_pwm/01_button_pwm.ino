// Уровень 1: потенциометр задаёт яркость, кнопка включает/выключает LED.
// LED: D3 через резистор на GND; кнопка: D10 на GND; потенциометр: A0.

const byte LED_PWM = 3;
const byte BUTTON_PIN = 10;
const byte POT_PIN = A0;

struct Button {
  byte pin;
  bool stable;
  bool lastReading;
  unsigned long changedAt;
};

bool buttonPressed(Button &b);

Button button = {BUTTON_PIN, HIGH, HIGH, 0};
bool enabled = true;

bool buttonPressed(Button &b) {
  bool reading = digitalRead(b.pin);
  if (reading != b.lastReading) {
    b.lastReading = reading;
    b.changedAt = millis();
  }

  if (millis() - b.changedAt >= 25 && reading != b.stable) {
    b.stable = reading;
    return b.stable == LOW;
  }
  return false;
}

void setup() {
  pinMode(LED_PWM, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  Serial.begin(115200);
}

void loop() {
  if (buttonPressed(button)) {
    enabled = !enabled;
    Serial.println(enabled ? F("LED enabled") : F("LED disabled"));
  }

  int adc = analogRead(POT_PIN); // 0...1023
  byte brightness = adc >> 2;    // 0...255
  analogWrite(LED_PWM, enabled ? brightness : 0);
}
