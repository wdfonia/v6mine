// Универсальная заготовка: 8 LED, 3 кнопки, 2 потенциометра, таймер без delay.
// Замени содержимое updateLogic() под условие задачи.

const byte LED_FIRST = 2;
const byte LED_COUNT = 8;
const byte BUTTON_COUNT = 3;
const byte BUTTON_PINS[BUTTON_COUNT] = {10, 11, 12};
const byte POT_PINS[2] = {A0, A1};

struct Button {
  byte pin;
  bool stable;
  bool lastReading;
  unsigned long changedAt;
  bool pressEvent;
};

Button buttons[BUTTON_COUNT];
byte outputValue = 0;
unsigned long lastTick = 0;

void buttonsBegin() {
  for (byte i = 0; i < BUTTON_COUNT; ++i) {
    buttons[i].pin = BUTTON_PINS[i];
    buttons[i].stable = HIGH;
    buttons[i].lastReading = HIGH;
    buttons[i].changedAt = 0;
    buttons[i].pressEvent = false;
    pinMode(buttons[i].pin, INPUT_PULLUP);
  }
}

void buttonsUpdate() {
  for (byte i = 0; i < BUTTON_COUNT; ++i) {
    Button &b = buttons[i];
    b.pressEvent = false;
    bool reading = digitalRead(b.pin);
    if (reading != b.lastReading) {
      b.lastReading = reading;
      b.changedAt = millis();
    }
    if (millis() - b.changedAt >= 25 && reading != b.stable) {
      b.stable = reading;
      if (b.stable == LOW) b.pressEvent = true;
    }
  }
}

bool wasPressed(byte index) {
  return index < BUTTON_COUNT && buttons[index].pressEvent;
}

bool isHeld(byte index) {
  return index < BUTTON_COUNT && buttons[index].stable == LOW;
}

void showByteSimple(byte value) {
  for (byte bit = 0; bit < LED_COUNT; ++bit) {
    digitalWrite(LED_FIRST + bit, bitRead(value, bit));
  }
}

void updateLogic() {
  // Демонстрационная логика:
  // B1 устанавливает бит, B2 сбрасывает, B3 инвертирует весь байт.
  // A0 выбирает номер бита 0...7, A1 — период автоинверсии 100...1500 мс.
  byte selectedBit = map(analogRead(POT_PINS[0]), 0, 1023, 0, 7);

  if (wasPressed(0)) bitSet(outputValue, selectedBit);
  if (wasPressed(1)) bitClear(outputValue, selectedBit);
  if (wasPressed(2)) outputValue = (byte)~outputValue;

  unsigned long interval = map(analogRead(POT_PINS[1]), 0, 1023, 100, 1500);
  if (isHeld(0) && isHeld(1) && millis() - lastTick >= interval) {
    lastTick = millis();
    outputValue ^= (byte)(1u << selectedBit);
  }
}

void setup() {
  for (byte pin = LED_FIRST; pin < LED_FIRST + LED_COUNT; ++pin) {
    pinMode(pin, OUTPUT);
  }
  buttonsBegin();
  Serial.begin(115200);
}

void loop() {
  buttonsUpdate();
  updateLogic();
  showByteSimple(outputValue);
}

