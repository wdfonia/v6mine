#ifndef BIT_TOOLS_H
#define BIT_TOOLS_H

#include <Arduino.h>

inline byte setBit8(byte x, byte n) {
  return (n < 8) ? (byte)(x | (1u << n)) : x;
}

inline byte clearBit8(byte x, byte n) {
  return (n < 8) ? (byte)(x & ~(1u << n)) : x;
}

inline byte toggleBit8(byte x, byte n) {
  return (n < 8) ? (byte)(x ^ (1u << n)) : x;
}

inline bool getBit8(byte x, byte n) {
  return n < 8 && (x & (1u << n));
}

inline byte rotateLeft8(byte x, byte count = 1) {
  count &= 7;
  if (count == 0) return x;
  return (byte)((x << count) | (x >> (8 - count)));
}

inline byte rotateRight8(byte x, byte count = 1) {
  count &= 7;
  if (count == 0) return x;
  return (byte)((x >> count) | (x << (8 - count)));
}

inline byte reverseBits8(byte x) {
  x = (byte)(((x & 0x55) << 1) | ((x >> 1) & 0x55));
  x = (byte)(((x & 0x33) << 2) | ((x >> 2) & 0x33));
  return (byte)((x << 4) | (x >> 4));
}

inline byte popcount8(byte x) {
  byte count = 0;
  while (x) {
    x &= (byte)(x - 1); // удаляем младшую единицу
    ++count;
  }
  return count;
}

inline bool evenParity8(byte x) {
  return (popcount8(x) & 1u) == 0;
}

inline byte binaryToGray8(byte x) {
  return x ^ (x >> 1);
}

inline byte grayToBinary8(byte gray) {
  byte binary = 0;
  for (; gray; gray >>= 1) binary ^= gray;
  return binary;
}

inline byte lowNibble(byte x) {
  return x & 0x0F;
}

inline byte highNibble(byte x) {
  return (x >> 4) & 0x0F;
}

inline byte joinNibbles(byte high, byte low) {
  return (byte)(((high & 0x0F) << 4) | (low & 0x0F));
}

inline byte swapNibbles(byte x) {
  return (byte)((x << 4) | (x >> 4));
}

inline bool isPowerOfTwo8(byte x) {
  return x != 0 && (x & (byte)(x - 1)) == 0;
}

inline byte lowestSetBitMask8(byte x) {
  return (byte)(x & (byte)(-x));
}

// Сложение по модулю 256 только через AND, XOR и сдвиг.
inline byte addBitwise8(byte a, byte b) {
  while (b != 0) {
    byte carry = (byte)((a & b) << 1);
    a ^= b;
    b = carry;
  }
  return a;
}

#endif
