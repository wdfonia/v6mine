// Пример использования готовых битовых функций из BitTools.h.
// A0 задаёт исходный байт, 8 LED на D2...D9 показывают его реверс.

#include "BitTools.h"

unsigned long lastPrint = 0;

void showByte(byte value) {
  for (byte i = 0; i < 8; ++i) {
    digitalWrite(2 + i, getBit8(value, i));
  }
}

void printBinary(byte x) {
  for (int i = 7; i >= 0; --i) Serial.print(getBit8(x, i));
}

void setup() {
  for (byte pin = 2; pin <= 9; ++pin) pinMode(pin, OUTPUT);
  Serial.begin(115200);
}

void loop() {
  byte x = analogRead(A0) >> 2;
  byte reversed = reverseBits8(x);
  showByte(reversed);

  if (millis() - lastPrint >= 300) {
    lastPrint = millis();
    Serial.print(F("x=")); printBinary(x);
    Serial.print(F(" reverse=")); printBinary(reversed);
    Serial.print(F(" ones=")); Serial.print(popcount8(x));
    Serial.print(F(" gray=")); printBinary(binaryToGray8(x));
    Serial.print(F(" power2=")); Serial.print(isPowerOfTwo8(x));
    Serial.println();
  }
}
