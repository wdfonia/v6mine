// Введи в монитор порта целое число 0...255 и нажми Enter.
// Скетч покажет двоичную/HEX запись, биты, реверс, Gray, вращения и чётность.
// 8 LED на D2...D9 показывают введённое число.

void showByte(byte value) {
  for (byte i = 0; i < 8; ++i) {
    digitalWrite(2 + i, bitRead(value, i));
  }
}

void printBinary(byte value) {
  Serial.print(F("0b"));
  for (int i = 7; i >= 0; --i) Serial.print(bitRead(value, i));
}

byte reverseBits(byte x) {
  x = (byte)(((x & 0x55) << 1) | ((x >> 1) & 0x55));
  x = (byte)(((x & 0x33) << 2) | ((x >> 2) & 0x33));
  return (byte)((x << 4) | (x >> 4));
}

byte countOnes(byte x) {
  byte count = 0;
  while (x) {
    x &= (byte)(x - 1);
    ++count;
  }
  return count;
}

byte rotateLeft(byte x) {
  return (byte)((x << 1) | (x >> 7));
}

byte rotateRight(byte x) {
  return (byte)((x >> 1) | (x << 7));
}

void printLabelAndByte(const __FlashStringHelper *label, byte value) {
  Serial.print(label);
  printBinary(value);
  Serial.print(F(" = "));
  Serial.println(value);
}

void analyze(byte x) {
  Serial.println(F("--------------------------"));
  Serial.print(F("DEC: ")); Serial.println(x);
  Serial.print(F("HEX: 0x"));
  if (x < 16) Serial.print('0');
  Serial.println(x, HEX);
  printLabelAndByte(F("BIN: "), x);
  printLabelAndByte(F("NOT: "), (byte)~x);
  printLabelAndByte(F("REV: "), reverseBits(x));
  printLabelAndByte(F("ROL: "), rotateLeft(x));
  printLabelAndByte(F("ROR: "), rotateRight(x));
  printLabelAndByte(F("GRAY: "), x ^ (x >> 1));
  Serial.print(F("Единичных битов: ")); Serial.println(countOnes(x));
  Serial.print(F("Чётность числа: "));
  Serial.println((x & 1) ? F("нечётное") : F("чётное"));
  Serial.print(F("Степень двойки: "));
  Serial.println(x != 0 && !(x & (byte)(x - 1)) ? F("да") : F("нет"));
  Serial.println(F("Введи следующее число 0...255:"));
}

void setup() {
  for (byte pin = 2; pin <= 9; ++pin) pinMode(pin, OUTPUT);
  Serial.begin(115200);
  Serial.setTimeout(50);
  Serial.println(F("Битовый калькулятор. Введи число 0...255:"));
}

void loop() {
  if (Serial.available() > 0) {
    long input = Serial.parseInt();
    while (Serial.available() > 0) Serial.read(); // удалить CR/LF
    input = constrain(input, 0, 255);
    byte x = (byte)input;
    showByte(x);
    analyze(x);
  }
}
