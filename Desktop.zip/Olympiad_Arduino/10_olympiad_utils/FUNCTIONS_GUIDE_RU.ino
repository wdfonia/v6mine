# Памятка по `OlympiadUtils.h`

Это заголовочная библиотека полезных функций для Arduino Uno. Скопируй папку
целиком, открой `10_olympiad_utils.ino` и загрузи скетч. Чтобы использовать
функции в своём скетче, положи `OlympiadUtils.h` рядом с `.ino` и добавь:

```cpp
#include "OlympiadUtils.h"
using namespace Olympiad;
```

Все номера битов считаются с нуля. В байте `0babcdefgh` младший правый бит `h`
имеет номер 0, а старший `a` — номер 7.

## 1. Системы счисления

Самый короткий встроенный способ печати:

```cpp
byte x = 45;
Serial.println(x, BIN); // 101101
Serial.println(x, OCT); // 55
Serial.println(x, DEC); // 45
Serial.println(x, HEX); // 2D
```

Встроенный `Serial.println()` не дополняет двоичное число ведущими нулями.
Для ровно восьми разрядов:

```cpp
printBinaryFixed(Serial, x, 8); // 00101101
```

Перевод числа в строку с основанием от 2 до 36:

```cpp
char text[33]; // 32 двоичных разряда unsigned long + символ '\0'

if (unsignedToBase(12345UL, 2, text, sizeof(text))) {
  Serial.println(text); // 11000000111001
}

unsignedToBase(255, 16, text, sizeof(text)); // "FF"
unsignedToBase(35, 36, text, sizeof(text));  // "Z"
```

Для отрицательных значений нужен буфер на один символ больше:

```cpp
char signedText[34];
signedToBase(-123, 2, signedText, sizeof(signedText)); // "-1111011"
```

Обратный перевод строки в число:

```cpp
unsigned long value;

if (baseToUnsigned("101101", 2, value)) {
  // value == 45
}

baseToUnsigned("FF", 16, value); // value == 255
baseToUnsigned("Z", 36, value);  // value == 35

long signedValue;
baseToSigned("-7B", 16, signedValue); // signedValue == -123
```

Функция вернёт `false` при неправильной цифре, базе вне `2...36` или
переполнении `unsigned long`.

BCD хранит каждую десятичную цифру в отдельном полубайте:

```cpp
byte bcd = decimalToBcd(45); // 0b01000101, это не двоичное число 45
int decimal = bcdToDecimal(bcd); // 45
```

## 2. Биты и маски

```cpp
byte x = 0b00101100;

bool bit3 = getBit8(x, 3); // прочитать третий бит
x = setBit8(x, 0);         // установить бит 0
x = clearBit8(x, 3);       // сбросить бит 3
x = toggleBit8(x, 5);      // инвертировать бит 5
x = writeBit8(x, 7, true); // записать конкретное значение
```

Те же действия стандартными средствами Arduino:

```cpp
bitRead(x, 3);
bitSet(x, 0);
bitClear(x, 3);
bitWrite(x, 7, 1);
```

Создание и использование масок:

```cpp
byte mask = lowBitsMask8(4); // 00001111
byte low4 = x & mask;         // оставить только младшие 4 бита
x |= mask;                    // установить выбранные биты
x &= ~mask;                   // сбросить выбранные биты
x ^= mask;                    // инвертировать выбранные биты
```

Работа с группой битов внутри байта:

```cpp
byte part = extractField8(0b11010110, 2, 3); // 00000101
byte y = writeField8(0b11110000, 1, 3, 0b101); // заменить биты 1...3
```

## 3. Обычные и циклические сдвиги

Обычный сдвиг теряет вышедший бит и вводит с другой стороны ноль:

```text
10110001 << 1 = 01100010
10110001 >> 1 = 01011000
```

```cpp
byte left = shiftLeft8(0b10110001, 1);   // 01100010
byte right = shiftRight8(0b10110001, 1); // 01011000
```

Циклический сдвиг возвращает выпавший бит с противоположной стороны:

```text
ROL: 10110001 -> 01100011
ROR: 10110001 -> 11011000
```

```cpp
byte rol = rotateLeft8(0b10110001, 1);  // 01100011
byte ror = rotateRight8(0b10110001, 1); // 11011000
```

Для более широких чисел есть `rotateLeft16()`, `rotateRight16()`,
`rotateLeft32()` и `rotateRight32()`. Два байта можно склеить или поменять
местами:

```cpp
uint16_t wordValue = joinBytes16(0x12, 0x34); // 0x1234
wordValue = swapBytes16(wordValue);           // 0x3412
```

Обычный правый сдвиг беззнакового числа вводит нули. Арифметический сдвиг
знакового числа сохраняет слева знак:

```cpp
int8_t negative = -16; // 11110000
negative = arithmeticShiftRight8(negative, 2); // -4, 11111100
```

Для программной имитации сдвигового регистра:

```cpp
x = shiftInFromRight8(x, newBit); // новый бит входит в позицию 0
x = shiftInFromLeft8(x, newBit);  // новый бит входит в позицию 7
```

Дополнительные функции:

```cpp
reverseBits8(x);       // 11010000 -> 00001011
swapNibbles8(x);       // 1011 0010 -> 0010 1011
countOnes8(x);         // количество единиц
hasEvenParity8(x);     // чётное ли количество единиц
isPowerOfTwo8(x);      // ровно один единичный бит
lowestSetBitMask8(x);  // маска младшей единицы
binaryToGray8(x);      // двоичный код -> код Грея
grayToBinary8(x);      // код Грея -> двоичный
addBitwise8(a, b);     // сумма по модулю 256 через AND/XOR/сдвиг
```

## 4. Математика

```cpp
unsigned long g = gcdUnsigned(48, 18); // НОД = 6

unsigned long result;
if (lcmUnsigned(48, 18, result)) {
  // НОК result == 144; false означал бы переполнение
}

powerUnsigned(3, 5, result); // 3^5 = 243 с проверкой переполнения
isPrime(97);                 // true
integerSqrt(20);             // 4, только целая часть
digitSum(12345);             // 15
absoluteDifference(10, 17); // 7
mapClamped(adc, 0, 1023, 0, 100); // сразу map + ограничение
```

## 5. Массивы

```cpp
int numbers[] = {7, 2, 9, 2, 5};
const size_t count = sizeof(numbers) / sizeof(numbers[0]);

long sum = arraySum(numbers, count);
float average = arrayAverage(numbers, count);

int minimum, maximum;
arrayMinMax(numbers, count, minimum, maximum);

int index = linearSearch(numbers, count, 9); // 2
reverseArray(numbers, count);
bubbleSort(numbers, count); // сортировка по возрастанию
int middle = medianOfThree(100, 20, 50); // 50
```

Передача массива в функцию не передаёт его размер автоматически — поэтому
длина всегда идёт отдельным аргументом.

## 6. АЦП, PWM и фильтры

```cpp
int raw = analogRead(A0);          // 0...1023
byte pwm = adc10ToByte(raw);       // 0...255
float volts = adcToVoltage(raw);   // при опорном напряжении 5 В
analogWrite(3, pwm);

byte half = percentToPwm(50);      // около 127
```

Гистерезис для датчика:

```cpp
bool heaterOn = false;

void loop() {
  int sensor = analogRead(A0);
  heaterOn = hysteresis(sensor, 450, 550, heaterOn);
  // включится при >=550, выключится при <=450
}
```

Скользящее среднее восьми измерений:

```cpp
MovingAverage8 filter;

void loop() {
  int filtered = filter.add(analogRead(A0));
}
```

Экспоненциальный фильтр использует меньше истории, но вычисляет `float`:

```cpp
ExponentialFilter filter(0.2f);
float filtered = filter.add(analogRead(A0));
```

## 7. Таймер без `delay()`

```cpp
PeriodicTimer timer(500);

void setup() {
  timer.begin();
}

void loop() {
  if (timer.ready()) {
    // выполняется примерно раз в 500 мс,
    // остальной loop всё время продолжает работать
  }
}
```

`delay(500)` останавливает весь скетч, а такой таймер позволяет одновременно
опрашивать кнопки, датчики и обновлять эффекты.

## 8. Кнопка без дребезга

Кнопка подключена между `D10` и `GND`; внешний подтягивающий резистор не нужен:

```cpp
DebouncedButton button(10);

void setup() {
  button.begin(); // включает INPUT_PULLUP
}

void loop() {
  button.update(); // строго один раз в каждом проходе loop

  if (button.wasPressed()) {
    // одно событие на одно физическое нажатие
  }

  if (button.wasReleased()) {
    // событие отпускания
  }

  if (button.heldFor(1000)) {
    // кнопка удерживается не меньше секунды
  }
}
```

## 9. Контрольные суммы

```cpp
byte packet[] = {10, 20, 30, 40};
size_t length = sizeof(packet);

byte simpleXor = xorChecksum8(packet, length);
byte simpleSum = sumChecksum8(packet, length);
byte reliable = crc8(packet, length);
```

Контрольная сумма позволяет заметить повреждение данных, но не исправляет его.
Для протокола передатчик и приёмник должны использовать один алгоритм CRC.

## 10. Восемь светодиодов

Понятный универсальный способ:

```cpp
beginByteLeds(2);               // D2...D9 как OUTPUT
showByteLeds(0b10100101, 2);    // бит 0 -> D2, бит 7 -> D9
```

Быстрый способ через регистры именно для Uno/Nano ATmega328P:

```cpp
beginByteLedsUnoFast();
showByteLedsUnoFast(0b10100101);
```

Быстрый вариант сохраняет состояния `D0/D1` и `D10...D13`, поэтому Serial и
три кнопки продолжают работать.
