// Демонстрация OlympiadUtils.h на всём комплекте.
//
// LED D2...D9 показывают результат операции.
// Кнопка D10: предыдущая операция.
// Кнопка D11: следующая операция.
// Кнопка D12: заморозить/разморозить показания потенциометров.
// A0 задаёт байт A, A1 задаёт байт B и число сдвига B&7.
// Подробный результат выводится в Serial Monitor, 115200 бод.

#include "OlympiadUtils.h"

using namespace Olympiad;

const byte OPERATION_COUNT = 13;

DebouncedButton previousButton(10);
DebouncedButton nextButton(11);
DebouncedButton freezeButton(12);
PeriodicTimer printTimer(350);

byte operation = 0;
byte valueA = 0;
byte valueB = 0;
bool frozen = false;

const __FlashStringHelper *operationName(byte selectedOperation) {
  switch (selectedOperation) {
    case 0:  return F("A (без изменения)");
    case 1:  return F("NOT A");
    case 2:  return F("A AND B");
    case 3:  return F("A OR B");
    case 4:  return F("A XOR B");
    case 5:  return F("A << n (обычный)");
    case 6:  return F("A >> n (обычный)");
    case 7:  return F("ROL A (циклический влево)");
    case 8:  return F("ROR A (циклический вправо)");
    case 9:  return F("reverseBits(A)");
    case 10: return F("Gray(A)");
    case 11: return F("маска младших n бит");
    case 12: return F("A + B только через биты");
  }
  return F("?");
}

byte calculateResult() {
  byte shiftCount = valueB & 7; // остаток от деления на 8
  switch (operation) {
    case 0:  return valueA;
    case 1:  return (byte)~valueA;
    case 2:  return valueA & valueB;
    case 3:  return valueA | valueB;
    case 4:  return valueA ^ valueB;
    case 5:  return shiftLeft8(valueA, shiftCount);
    case 6:  return shiftRight8(valueA, shiftCount);
    case 7:  return rotateLeft8(valueA, shiftCount);
    case 8:  return rotateRight8(valueA, shiftCount);
    case 9:  return reverseBits8(valueA);
    case 10: return binaryToGray8(valueA);
    case 11: return valueA & lowBitsMask8((valueB & 7) + 1);
    case 12: return addBitwise8(valueA, valueB);
  }
  return 0;
}

void printValue(const __FlashStringHelper *label, byte value) {
  Serial.print(label);
  Serial.print(value);
  Serial.print(F(" = "));
  printBinaryFixed(Serial, value, 8);
  Serial.print(F(" = 0x"));
  if (value < 16) Serial.print('0');
  Serial.print(value, HEX);
}

void printState(byte result) {
  char converted[33];

  Serial.println(F("------------------------------------------------"));
  Serial.print(frozen ? F("[ЗАМОРОЖЕНО] ") : F("[LIVE] "));
  Serial.println(operationName(operation));

  printValue(F("A: "), valueA);
  Serial.println();
  printValue(F("B: "), valueB);
  Serial.print(F("; n=B&7="));
  Serial.println(valueB & 7);
  printValue(F("R: "), result);
  Serial.println();

  // Одна и та же величина в разных системах счисления.
  unsignedToBase(result, 2, converted, sizeof(converted));
  Serial.print(F("R в base 2:  ")); Serial.println(converted);
  unsignedToBase(result, 8, converted, sizeof(converted));
  Serial.print(F("R в base 8:  ")); Serial.println(converted);
  unsignedToBase(result, 16, converted, sizeof(converted));
  Serial.print(F("R в base 16: ")); Serial.println(converted);
  unsignedToBase(result, 36, converted, sizeof(converted));
  Serial.print(F("R в base 36: ")); Serial.println(converted);
}

void setup() {
  beginByteLedsUnoFast();
  previousButton.begin();
  nextButton.begin();
  freezeButton.begin();

  Serial.begin(115200);
  printTimer.begin();
  Serial.println(F("Библиотека OlympiadUtils: D10/D11 — операция, D12 — freeze."));
}

void loop() {
  unsigned long now = millis();
  previousButton.update(now);
  nextButton.update(now);
  freezeButton.update(now);

  bool forcePrint = false;

  if (previousButton.wasPressed()) {
    operation = (operation + OPERATION_COUNT - 1) % OPERATION_COUNT;
    forcePrint = true;
  }
  if (nextButton.wasPressed()) {
    operation = (operation + 1) % OPERATION_COUNT;
    forcePrint = true;
  }
  if (freezeButton.wasPressed()) {
    frozen = !frozen;
    forcePrint = true;
  }

  if (!frozen) {
    valueA = adc10ToByte(analogRead(A0));
    valueB = adc10ToByte(analogRead(A1));
  }

  byte result = calculateResult();
  showByteLedsUnoFast(result);

  if (forcePrint) {
    // После ручного переключения начинаем период печати заново.
    printTimer.begin(now);
    printState(result);
  } else if (printTimer.ready(now)) {
    printState(result);
  }
}
