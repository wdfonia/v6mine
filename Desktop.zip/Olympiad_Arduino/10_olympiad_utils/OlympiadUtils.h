#ifndef OLYMPIAD_UTILS_H
#define OLYMPIAD_UTILS_H

// Универсальные функции для Arduino Uno.
// Подключение: #include "OlympiadUtils.h"
// Все имена находятся в Olympiad::, чтобы не конфликтовать с библиотеками.

#include <Arduino.h>
#include <limits.h>

namespace Olympiad {

// ============================================================================
// 1. СИСТЕМЫ СЧИСЛЕНИЯ
// ============================================================================

// Превращает цифру 0...35 в символ '0'...'9', 'A'...'Z'.
// Если цифра недопустима, возвращает '?'.
inline char digitToChar(byte digit) {
  if (digit < 10) return (char)('0' + digit);
  if (digit < 36) return (char)('A' + digit - 10);
  return '?';
}

// Обратная операция: символ цифры -> значение 0...35.
// Понимает и большие, и маленькие латинские буквы. Ошибка -> -1.
inline int8_t charToDigit(char symbol) {
  if (symbol >= '0' && symbol <= '9') return symbol - '0';
  if (symbol >= 'A' && symbol <= 'Z') return symbol - 'A' + 10;
  if (symbol >= 'a' && symbol <= 'z') return symbol - 'a' + 10;
  return -1;
}

// Переводит unsigned long в систему счисления base (2...36).
// Результат записывается в output как обычная C-строка с завершающим '\0'.
// Для 32-битного числа в двоичной системе нужен буфер минимум char text[33].
// Возвращает true при успехе и false при неверной базе/маленьком буфере.
inline bool unsignedToBase(unsigned long value, byte base,
                           char *output, size_t outputSize) {
  if (output == NULL || outputSize == 0) return false;
  output[0] = '\0';
  if (base < 2 || base > 36) return false;

  char reversed[32];
  byte length = 0;
  do {
    reversed[length++] = digitToChar((byte)(value % base));
    value /= base;
  } while (value != 0);

  if ((size_t)length + 1 > outputSize) return false;
  for (byte i = 0; i < length; ++i) {
    output[i] = reversed[length - 1 - i];
  }
  output[length] = '\0';
  return true;
}

// Версия для знакового long. Минус также занимает место в буфере.
inline bool signedToBase(long value, byte base,
                         char *output, size_t outputSize) {
  if (output == NULL || outputSize == 0) return false;
  output[0] = '\0';
  bool negative = value < 0;

  // Вычитание в unsigned корректно даже для LONG_MIN, где обычный -value опасен.
  unsigned long magnitude = negative
      ? 0UL - (unsigned long)value
      : (unsigned long)value;

  char digits[33];
  if (!unsignedToBase(magnitude, base, digits, sizeof(digits))) return false;
  size_t length = strlen(digits);
  size_t needed = length + (negative ? 1 : 0) + 1;
  if (needed > outputSize) return false;

  byte position = 0;
  if (negative) output[position++] = '-';
  memcpy(output + position, digits, length + 1);
  return true;
}

// Разбирает строку text в системе base (2...36).
// Пример: baseToUnsigned("101101", 2, value) запишет в value число 45.
// Проверяет неправильные символы и переполнение unsigned long.
inline bool baseToUnsigned(const char *text, byte base,
                           unsigned long &result) {
  result = 0;
  if (text == NULL || base < 2 || base > 36) return false;

  while (*text == ' ' || *text == '\t') ++text;
  if (*text == '+') ++text;

  bool hasDigits = false;
  while (*text != '\0' && *text != ' ' && *text != '\t' &&
         *text != '\r' && *text != '\n') {
    int8_t digit = charToDigit(*text++);
    if (digit < 0 || digit >= base) return false;
    if (result > (ULONG_MAX - (byte)digit) / base) return false;
    result = result * base + (byte)digit;
    hasDigits = true;
  }

  while (*text == ' ' || *text == '\t' || *text == '\r' || *text == '\n') {
    ++text;
  }
  return hasDigits && *text == '\0';
}

// Знаковая версия обратного перевода. Понимает необязательные '+' и '-'.
inline bool baseToSigned(const char *text, byte base, long &result) {
  result = 0;
  if (text == NULL || base < 2 || base > 36) return false;

  while (*text == ' ' || *text == '\t') ++text;
  bool negative = false;
  if (*text == '+' || *text == '-') {
    negative = *text == '-';
    ++text;
  }

  unsigned long magnitude = 0;
  if (!baseToUnsigned(text, base, magnitude)) return false;

  if (!negative) {
    if (magnitude > (unsigned long)LONG_MAX) return false;
    result = (long)magnitude;
    return true;
  }

  unsigned long negativeLimit = (unsigned long)LONG_MAX + 1UL;
  if (magnitude > negativeLimit) return false;
  if (magnitude == negativeLimit) result = LONG_MIN;
  else result = -(long)magnitude;
  return true;
}

// Печатает ровно width двоичных разрядов, включая ведущие нули.
// width ограничивается диапазоном 1...32.
inline void printBinaryFixed(Print &output, unsigned long value, byte width) {
  if (width > 32) width = 32;
  for (int8_t bit = (int8_t)width - 1; bit >= 0; --bit) {
    output.print((value >> bit) & 1UL);
  }
}

// Десятичное 0...99 -> упакованный BCD: 45 -> 0b01000101.
// Возвращает 0xFF, если decimal > 99.
inline byte decimalToBcd(byte decimal) {
  if (decimal > 99) return 0xFF;
  return (byte)(((decimal / 10) << 4) | (decimal % 10));
}

// Упакованный BCD -> десятичное число. Неверный BCD -> -1.
inline int bcdToDecimal(byte bcd) {
  byte tens = (bcd >> 4) & 0x0F;
  byte ones = bcd & 0x0F;
  if (tens > 9 || ones > 9) return -1;
  return tens * 10 + ones;
}

// ============================================================================
// 2. БИТЫ, МАСКИ И СДВИГИ
// ============================================================================

// Маска из count младших единиц: count=3 -> 0b00000111.
inline byte lowBitsMask8(byte count) {
  if (count == 0) return 0;
  if (count >= 8) return 0xFF;
  return (byte)((1u << count) - 1u);
}

inline bool getBit8(byte value, byte bitNumber) {
  return bitNumber < 8 && (value & (1u << bitNumber));
}

inline byte setBit8(byte value, byte bitNumber) {
  return bitNumber < 8 ? (byte)(value | (1u << bitNumber)) : value;
}

inline byte clearBit8(byte value, byte bitNumber) {
  return bitNumber < 8 ? (byte)(value & ~(1u << bitNumber)) : value;
}

inline byte toggleBit8(byte value, byte bitNumber) {
  return bitNumber < 8 ? (byte)(value ^ (1u << bitNumber)) : value;
}

// Записывает в выбранный бит true (1) или false (0).
inline byte writeBit8(byte value, byte bitNumber, bool newBit) {
  return newBit ? setBit8(value, bitNumber) : clearBit8(value, bitNumber);
}

// Извлекает count битов, начиная с firstBit.
// extractField8(0b11010110, 2, 3) -> 0b00000101.
inline byte extractField8(byte value, byte firstBit, byte count) {
  if (firstBit >= 8 || count == 0) return 0;
  if (count > 8 - firstBit) count = 8 - firstBit;
  return (byte)((value >> firstBit) & lowBitsMask8(count));
}

// Заменяет count битов value, начиная с firstBit, младшими битами field.
inline byte writeField8(byte value, byte firstBit, byte count, byte field) {
  if (firstBit >= 8 || count == 0) return value;
  if (count > 8 - firstBit) count = 8 - firstBit;
  byte mask = (byte)(lowBitsMask8(count) << firstBit);
  value &= (byte)~mask;
  value |= (byte)((field << firstBit) & mask);
  return value;
}

// Обычный НЕциклический сдвиг: потерянные биты исчезают, новые равны нулю.
// Встроенная запись делает то же: value << count и value >> count.
// Проверка count>=8 убирает неопределённое поведение большого сдвига.
inline byte shiftLeft8(byte value, byte count) {
  return count >= 8 ? 0 : (byte)(value << count);
}

inline byte shiftRight8(byte value, byte count) {
  return count >= 8 ? 0 : (byte)(value >> count);
}

// Знаковый (арифметический) сдвиг вправо сохраняет старший знаковый бит.
// Например, -16 (11110000) >> 2 превращается в -4 (11111100).
inline int8_t arithmeticShiftRight8(int8_t value, byte count) {
  if (count >= 8) return value < 0 ? -1 : 0;
  byte raw = (byte)value;
  while (count-- > 0) {
    raw = (byte)((raw >> 1) | (raw & 0x80));
  }
  return (int8_t)raw;
}

// Циклический сдвиг (rotate): выпавшие биты возвращаются с другой стороны.
inline byte rotateLeft8(byte value, byte count = 1) {
  count &= 7; // count %= 8
  if (count == 0) return value;
  return (byte)((value << count) | (value >> (8 - count)));
}

inline byte rotateRight8(byte value, byte count = 1) {
  count &= 7;
  if (count == 0) return value;
  return (byte)((value >> count) | (value << (8 - count)));
}

// Те же циклические сдвиги для 16- и 32-битных беззнаковых чисел.
inline uint16_t rotateLeft16(uint16_t value, byte count = 1) {
  count &= 15;
  if (count == 0) return value;
  return (uint16_t)((value << count) | (value >> (16 - count)));
}

inline uint16_t rotateRight16(uint16_t value, byte count = 1) {
  count &= 15;
  if (count == 0) return value;
  return (uint16_t)((value >> count) | (value << (16 - count)));
}

inline uint32_t rotateLeft32(uint32_t value, byte count = 1) {
  count &= 31;
  if (count == 0) return value;
  return (uint32_t)((value << count) | (value >> (32 - count)));
}

inline uint32_t rotateRight32(uint32_t value, byte count = 1) {
  count &= 31;
  if (count == 0) return value;
  return (uint32_t)((value >> count) | (value << (32 - count)));
}

// Склеивание двух байтов и перестановка байтов в 16-битном числе.
inline uint16_t joinBytes16(byte highPart, byte lowPart) {
  return (uint16_t)(((uint16_t)highPart << 8) | lowPart);
}

inline uint16_t swapBytes16(uint16_t value) {
  return (uint16_t)((value << 8) | (value >> 8));
}

// Сдвигает всё влево и вводит новый бит справа в позицию 0.
inline byte shiftInFromRight8(byte value, bool newBit) {
  return (byte)((value << 1) | (newBit ? 1 : 0));
}

// Сдвигает всё вправо и вводит новый бит слева в позицию 7.
inline byte shiftInFromLeft8(byte value, bool newBit) {
  return (byte)((value >> 1) | (newBit ? 0x80 : 0));
}

// Зеркально меняет порядок всех восьми битов: abcdefgh -> hgfedcba.
inline byte reverseBits8(byte value) {
  value = (byte)(((value & 0x55) << 1) | ((value >> 1) & 0x55));
  value = (byte)(((value & 0x33) << 2) | ((value >> 2) & 0x33));
  return (byte)((value << 4) | (value >> 4));
}

inline byte swapNibbles8(byte value) {
  return (byte)((value << 4) | (value >> 4));
}

// Количество единичных битов. x &= x-1 удаляет младшую единицу.
inline byte countOnes8(byte value) {
  byte count = 0;
  while (value != 0) {
    value &= (byte)(value - 1);
    ++count;
  }
  return count;
}

inline bool hasEvenParity8(byte value) {
  return (countOnes8(value) & 1u) == 0;
}

inline bool isPowerOfTwo8(byte value) {
  return value != 0 && (value & (byte)(value - 1)) == 0;
}

// Возвращает маску самой младшей единицы: 10110000 -> 00010000.
inline byte lowestSetBitMask8(byte value) {
  return (byte)(value & (byte)(-value));
}

inline byte binaryToGray8(byte binary) {
  return binary ^ (binary >> 1);
}

inline byte grayToBinary8(byte gray) {
  byte binary = 0;
  while (gray != 0) {
    binary ^= gray;
    gray >>= 1;
  }
  return binary;
}

// Сложение по модулю 256 без оператора +: XOR складывает без переноса,
// AND находит переносы. Переполнение выше восьмого бита отбрасывается.
inline byte addBitwise8(byte a, byte b) {
  while (b != 0) {
    byte carry = (byte)((a & b) << 1);
    a ^= b;
    b = carry;
  }
  return a;
}

// ============================================================================
// 3. МАТЕМАТИКА И ЧИСЛА
// ============================================================================

inline unsigned long gcdUnsigned(unsigned long a, unsigned long b) {
  while (b != 0) {
    unsigned long remainder = a % b;
    a = b;
    b = remainder;
  }
  return a;
}

// Безопасный НОК. Возвращает false, если результат не влезает в unsigned long.
inline bool lcmUnsigned(unsigned long a, unsigned long b,
                        unsigned long &result) {
  if (a == 0 || b == 0) {
    result = 0;
    return true;
  }
  unsigned long reduced = a / gcdUnsigned(a, b);
  if (reduced > ULONG_MAX / b) return false;
  result = reduced * b;
  return true;
}

// Быстрое возведение в целую степень с проверкой переполнения.
inline bool powerUnsigned(unsigned long base, byte exponent,
                          unsigned long &result) {
  result = 1;
  unsigned long factor = base;
  while (exponent != 0) {
    if (exponent & 1u) {
      if (factor != 0 && result > ULONG_MAX / factor) return false;
      result *= factor;
    }
    exponent >>= 1;
    if (exponent != 0) {
      if (factor != 0 && factor > ULONG_MAX / factor) return false;
      factor *= factor;
    }
  }
  return true;
}

// Проверка простоты без риска переполнения в условии divisor*divisor <= n.
inline bool isPrime(unsigned long number) {
  if (number < 2) return false;
  if ((number & 1UL) == 0) return number == 2;
  for (unsigned long divisor = 3;
       divisor <= number / divisor;
       divisor += 2) {
    if (number % divisor == 0) return false;
  }
  return true;
}

// Целая часть квадратного корня. Например, integerSqrt(20) == 4.
inline unsigned long integerSqrt(unsigned long number) {
  unsigned long result = 0;
  unsigned long bit = 1UL << 30; // наибольшая степень 4 для 32 бит
  while (bit > number) bit >>= 2;

  while (bit != 0) {
    if (number >= result + bit) {
      number -= result + bit;
      result = (result >> 1) + bit;
    } else {
      result >>= 1;
    }
    bit >>= 2;
  }
  return result;
}

// Сумма цифр числа в выбранной системе счисления.
inline unsigned int digitSum(unsigned long value, byte base = 10) {
  if (base < 2 || base > 36) return 0;
  unsigned int sum = 0;
  do {
    sum += value % base;
    value /= base;
  } while (value != 0);
  return sum;
}

inline unsigned long absoluteDifference(unsigned long a, unsigned long b) {
  return a >= b ? a - b : b - a;
}

// Ограничивает value от minimum до maximum включительно.
inline long clampLong(long value, long minimum, long maximum) {
  if (value < minimum) return minimum;
  if (value > maximum) return maximum;
  return value;
}

// Аналог Arduino map(), но сначала ограничивает вход заданным диапазоном.
inline long mapClamped(long value, long inMin, long inMax,
                       long outMin, long outMax) {
  if (inMin == inMax) return outMin;
  if (inMin < inMax) value = clampLong(value, inMin, inMax);
  else value = clampLong(value, inMax, inMin);
  return (value - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;
}

// ============================================================================
// 4. МАССИВЫ int
// ============================================================================

inline long arraySum(const int *values, size_t length) {
  long sum = 0;
  for (size_t i = 0; i < length; ++i) sum += values[i];
  return sum;
}

inline float arrayAverage(const int *values, size_t length) {
  return length == 0 ? 0.0f : (float)arraySum(values, length) / length;
}

// Записывает минимум/максимум по ссылкам. Пустой массив -> false.
inline bool arrayMinMax(const int *values, size_t length,
                        int &minimum, int &maximum) {
  if (values == NULL || length == 0) return false;
  minimum = maximum = values[0];
  for (size_t i = 1; i < length; ++i) {
    if (values[i] < minimum) minimum = values[i];
    if (values[i] > maximum) maximum = values[i];
  }
  return true;
}

inline void reverseArray(int *values, size_t length) {
  for (size_t left = 0; left < length / 2; ++left) {
    size_t right = length - 1 - left;
    int temporary = values[left];
    values[left] = values[right];
    values[right] = temporary;
  }
}

// Простая сортировка для коротких олимпиадных массивов.
inline void bubbleSort(int *values, size_t length) {
  if (length < 2) return;
  for (size_t unsorted = length; unsorted > 1; --unsorted) {
    bool changed = false;
    for (size_t i = 1; i < unsorted; ++i) {
      if (values[i - 1] > values[i]) {
        int temporary = values[i - 1];
        values[i - 1] = values[i];
        values[i] = temporary;
        changed = true;
      }
    }
    if (!changed) break;
  }
}

// Возвращает индекс найденного элемента или -1.
inline int linearSearch(const int *values, size_t length, int target) {
  for (size_t i = 0; i < length; ++i) {
    if (values[i] == target) return (int)i;
  }
  return -1;
}

inline int medianOfThree(int a, int b, int c) {
  if (a > b) { int t = a; a = b; b = t; }
  if (b > c) { int t = b; b = c; c = t; }
  if (a > b) { int t = a; a = b; b = t; }
  return b;
}

// ============================================================================
// 5. АЦП, ШИМ И ФИЛЬТРАЦИЯ
// ============================================================================

inline byte adc10ToByte(int adc) {
  if (adc <= 0) return 0;
  if (adc >= 1023) return 255;
  return (byte)(adc >> 2);
}

inline float adcToVoltage(int adc, float referenceVoltage = 5.0f) {
  adc = (int)clampLong(adc, 0, 1023);
  return adc * referenceVoltage / 1023.0f;
}

inline byte percentToPwm(int percent) {
  percent = (int)clampLong(percent, 0, 100);
  return (byte)((percent * 255L + 50) / 100);
}

// Гистерезис не даёт состоянию дрожать около одного порога.
// Включаемся при value>=highThreshold, выключаемся при value<=lowThreshold.
inline bool hysteresis(int value, int lowThreshold, int highThreshold,
                       bool currentState) {
  if (!currentState && value >= highThreshold) return true;
  if (currentState && value <= lowThreshold) return false;
  return currentState;
}

// Скользящее среднее последних восьми значений без динамической памяти.
class MovingAverage8 {
 public:
  MovingAverage8() : _sum(0), _position(0), _count(0) {
    for (byte i = 0; i < 8; ++i) _values[i] = 0;
  }

  int add(int value) {
    _sum -= _values[_position];
    _values[_position] = value;
    _sum += value;
    _position = (_position + 1) & 7;
    if (_count < 8) ++_count;
    return (int)(_sum / _count);
  }

  void reset() {
    _sum = 0;
    _position = 0;
    _count = 0;
    for (byte i = 0; i < 8; ++i) _values[i] = 0;
  }

 private:
  int _values[8];
  long _sum;
  byte _position;
  byte _count;
};

// Экспоненциальный фильтр. alpha ближе к 1 реагирует быстрее,
// ближе к 0 сглаживает сильнее.
class ExponentialFilter {
 public:
  explicit ExponentialFilter(float alpha = 0.2f)
      : _alpha(alpha), _value(0.0f), _initialized(false) {
    if (_alpha < 0.0f) _alpha = 0.0f;
    if (_alpha > 1.0f) _alpha = 1.0f;
  }

  float add(float sample) {
    if (!_initialized) {
      _value = sample;
      _initialized = true;
    } else {
      _value += _alpha * (sample - _value);
    }
    return _value;
  }

  void reset() { _initialized = false; }

 private:
  float _alpha;
  float _value;
  bool _initialized;
};

// ============================================================================
// 6. ВРЕМЯ БЕЗ delay() И КНОПКА С АНТИДРЕБЕЗГОМ
// ============================================================================

// Возвращает true не чаще одного раза за intervalMs и обновляет lastTime.
// Вычитание millis()-lastTime корректно работает при переполнении millis().
inline bool intervalElapsed(unsigned long &lastTime, unsigned long intervalMs,
                            unsigned long now) {
  if (now - lastTime < intervalMs) return false;
  lastTime = now;
  return true;
}

class PeriodicTimer {
 public:
  explicit PeriodicTimer(unsigned long intervalMs = 1000)
      : _interval(intervalMs), _last(0) {}

  void begin(unsigned long now = millis()) { _last = now; }
  void setInterval(unsigned long intervalMs) { _interval = intervalMs; }

  bool ready(unsigned long now = millis()) {
    return intervalElapsed(_last, _interval, now);
  }

 private:
  unsigned long _interval;
  unsigned long _last;
};

// Кнопка по умолчанию подключается между pin и GND и использует INPUT_PULLUP.
// В loop() сначала один раз вызывай update(), затем проверяй wasPressed().
class DebouncedButton {
 public:
  explicit DebouncedButton(byte pin, unsigned long debounceMs = 25)
      : _pin(pin), _debounceMs(debounceMs), _activeLow(true),
        _rawDown(false), _stableDown(false), _pressedEvent(false),
        _releasedEvent(false), _rawChangedAt(0), _pressedAt(0) {}

  void begin(bool usePullup = true) {
    _activeLow = usePullup;
    pinMode(_pin, usePullup ? INPUT_PULLUP : INPUT);
    bool level = digitalRead(_pin);
    _rawDown = _stableDown = _activeLow ? level == LOW : level == HIGH;
    _rawChangedAt = millis();
    _pressedAt = _rawChangedAt;
  }

  void update(unsigned long now = millis()) {
    _pressedEvent = false;
    _releasedEvent = false;
    bool level = digitalRead(_pin);
    bool down = _activeLow ? level == LOW : level == HIGH;

    if (down != _rawDown) {
      _rawDown = down;
      _rawChangedAt = now;
    }

    if (now - _rawChangedAt >= _debounceMs && _stableDown != _rawDown) {
      _stableDown = _rawDown;
      if (_stableDown) {
        _pressedEvent = true;
        _pressedAt = now;
      } else {
        _releasedEvent = true;
      }
    }
  }

  bool wasPressed() const { return _pressedEvent; }
  bool wasReleased() const { return _releasedEvent; }
  bool isDown() const { return _stableDown; }

  bool heldFor(unsigned long durationMs,
               unsigned long now = millis()) const {
    return _stableDown && now - _pressedAt >= durationMs;
  }

 private:
  byte _pin;
  unsigned long _debounceMs;
  bool _activeLow;
  bool _rawDown;
  bool _stableDown;
  bool _pressedEvent;
  bool _releasedEvent;
  unsigned long _rawChangedAt;
  unsigned long _pressedAt;
};

// ============================================================================
// 7. КОНТРОЛЬНЫЕ СУММЫ
// ============================================================================

inline byte xorChecksum8(const byte *data, size_t length) {
  byte result = 0;
  for (size_t i = 0; i < length; ++i) result ^= data[i];
  return result;
}

inline byte sumChecksum8(const byte *data, size_t length) {
  byte result = 0;
  for (size_t i = 0; i < length; ++i) result += data[i];
  return result; // сумма по модулю 256
}

// CRC-8, полином 0x07, начальное значение 0.
inline byte crc8(const byte *data, size_t length) {
  byte crc = 0;
  for (size_t i = 0; i < length; ++i) {
    crc ^= data[i];
    for (byte bit = 0; bit < 8; ++bit) {
      crc = (crc & 0x80) ? (byte)((crc << 1) ^ 0x07)
                         : (byte)(crc << 1);
    }
  }
  return crc;
}

// ============================================================================
// 8. ВЫВОД БАЙТА НА ВОСЕМЬ СВЕТОДИОДОВ
// ============================================================================

inline void beginByteLeds(byte firstPin = 2) {
  for (byte bit = 0; bit < 8; ++bit) pinMode(firstPin + bit, OUTPUT);
}

inline void showByteLeds(byte value, byte firstPin = 2,
                         bool activeHigh = true) {
  for (byte bit = 0; bit < 8; ++bit) {
    bool level = getBit8(value, bit);
    digitalWrite(firstPin + bit, level == activeHigh ? HIGH : LOW);
  }
}

// Быстрый вариант именно для Uno/Nano ATmega328P и LED на D2...D9.
// Сохраняет D0/D1 (Serial) и D10...D13 (кнопки/SPI).
inline void beginByteLedsUnoFast() {
#if defined(__AVR_ATmega328P__)
  DDRD |= 0b11111100;
  DDRB |= 0b00000011;
#else
  beginByteLeds(2);
#endif
}

inline void showByteLedsUnoFast(byte value) {
#if defined(__AVR_ATmega328P__)
  PORTD = (PORTD & 0b00000011) | ((value & 0b00111111) << 2);
  PORTB = (PORTB & 0b11111100) | ((value >> 6) & 0b00000011);
#else
  showByteLeds(value, 2, true);
#endif
}

} // namespace Olympiad

#endif // OLYMPIAD_UTILS_H
