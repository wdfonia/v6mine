// Уровень 3: эффекты без delay().
// B1/B2 выбирают эффект, B3 пауза. A0 задаёт скорость.
// Эффекты: бегущий бит, заполнение, счётчик, Gray, LFSR-псевдослучайный.

const byte BTN_PREV = 10;
const byte BTN_NEXT = 11;
const byte BTN_PAUSE = 12;
const byte MODE_COUNT = 5;

struct Button {
  byte pin;
  bool stable;
  bool lastReading;
  unsigned long changedAt;
};

bool buttonPressed(Button &button);

Button prevButton = {BTN_PREV, HIGH, HIGH, 0};
Button nextButton = {BTN_NEXT, HIGH, HIGH, 0};
Button pauseButton = {BTN_PAUSE, HIGH, HIGH, 0};

byte mode = 0;
byte phase = 0;
byte lfsr = 0xA5; // не должен быть нулём
bool paused = false;
unsigned long lastStep = 0;

bool buttonPressed(Button &button) {
  bool reading = digitalRead(button.pin);
  if (reading != button.lastReading) {
    button.lastReading = reading;
    button.changedAt = millis();
  }
  if (millis() - button.changedAt >= 25 && reading != button.stable) {
    button.stable = reading;
    return button.stable == LOW;
  }
  return false;
}

void ledsBeginFast() {
  DDRD |= 0b11111100;
  DDRB |= 0b00000011;
}

void showByteFast(byte value) {
  PORTD = (PORTD & 0b00000011) | ((value & 0b00111111) << 2);
  PORTB = (PORTB & 0b11111100) | ((value >> 6) & 0b00000011);
}

void resetEffect() {
  phase = 0;
  lfsr = 0xA5;
  lastStep = millis();
}

void printMode() {
  Serial.print(F("Mode "));
  Serial.print(mode);
  Serial.print(F(": "));
  switch (mode) {
    case 0: Serial.println(F("running bit")); break;
    case 1: Serial.println(F("fill")); break;
    case 2: Serial.println(F("binary counter")); break;
    case 3: Serial.println(F("Gray code")); break;
    case 4: Serial.println(F("LFSR random")); break;
  }
}

byte nextFrame() {
  byte frame = 0;
  switch (mode) {
    case 0:
      frame = (byte)(1u << (phase & 7));
      ++phase;
      break;

    case 1: {
      byte p = phase % 16;
      frame = (p < 8) ? (byte)(0xFFu >> (7 - p))
                      : (byte)(0xFFu << (p - 7));
      ++phase;
      break;
    }

    case 2:
      frame = phase++;
      break;

    case 3:
      frame = phase ^ (phase >> 1);
      ++phase;
      break;

    case 4: {
      // Полином x^8+x^6+x^5+x^4+1, период до 255 состояний.
      bool feedback = bitRead(lfsr, 7) ^ bitRead(lfsr, 5) ^
                      bitRead(lfsr, 4) ^ bitRead(lfsr, 3);
      lfsr = (byte)((lfsr << 1) | feedback);
      frame = lfsr;
      break;
    }
  }
  return frame;
}

void setup() {
  ledsBeginFast();
  pinMode(BTN_PREV, INPUT_PULLUP);
  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(BTN_PAUSE, INPUT_PULLUP);
  Serial.begin(115200);
  printMode();
}

void loop() {
  if (buttonPressed(prevButton)) {
    mode = (mode + MODE_COUNT - 1) % MODE_COUNT;
    resetEffect();
    printMode();
  }
  if (buttonPressed(nextButton)) {
    mode = (mode + 1) % MODE_COUNT;
    resetEffect();
    printMode();
  }
  if (buttonPressed(pauseButton)) {
    paused = !paused;
    Serial.println(paused ? F("PAUSE") : F("RUN"));
  }

  unsigned long interval = map(analogRead(A0), 0, 1023, 35, 900);
  if (!paused && millis() - lastStep >= interval) {
    lastStep = millis();
    showByteFast(nextFrame());
  }
}
