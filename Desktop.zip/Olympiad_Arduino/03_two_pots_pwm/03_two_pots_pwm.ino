// Уровень 2: два потенциометра, два PWM LED и три режима.
// LED: D3 и D5; потенциометры: A0/A1; кнопка D10 переключает режим.

const byte LED_1 = 3;
const byte LED_2 = 5;
const byte POT_1 = A0;
const byte POT_2 = A1;
const byte BUTTON_PIN = 10;

byte mode = 0;
bool stable = HIGH;
bool lastReading = HIGH;
unsigned long changedAt = 0;
unsigned long lastPrint = 0;

bool pressed() {
  bool reading = digitalRead(BUTTON_PIN);
  if (reading != lastReading) {
    lastReading = reading;
    changedAt = millis();
  }
  if (millis() - changedAt >= 25 && reading != stable) {
    stable = reading;
    return stable == LOW;
  }
  return false;
}

void setup() {
  pinMode(LED_1, OUTPUT);
  pinMode(LED_2, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  Serial.begin(115200);
}

void loop() {
  if (pressed()) {
    mode = (mode + 1) % 3;
    Serial.print(F("Mode = "));
    Serial.println(mode);
  }

  int a = analogRead(POT_1);
  int b = analogRead(POT_2);
  byte out1 = 0;
  byte out2 = 0;

  switch (mode) {
    case 0: // независимая яркость
      out1 = a >> 2;
      out2 = b >> 2;
      break;

    case 1: // плавное перетекание от первого потенциометра
      out1 = a >> 2;
      out2 = 255 - out1;
      break;

    case 2: // аналоговый компаратор
      out1 = (a > b) ? 255 : 0;
      out2 = (b > a) ? 255 : 0;
      break;
  }

  analogWrite(LED_1, out1);
  analogWrite(LED_2, out2);

  if (millis() - lastPrint >= 250) {
    lastPrint = millis();
    Serial.print(F("A0=")); Serial.print(a);
    Serial.print(F(" A1=")); Serial.print(b);
    Serial.print(F(" PWM=")); Serial.print(out1);
    Serial.print(','); Serial.println(out2);
  }
}

