#include <Servo.h>

const int SERVO_LEFT_PIN = 2;
const int SERVO_RIGHT_PIN = 3;

const int LED1 = 12;
const int LED2 = 9;
const int LED3 = 10;
const int LED4 = 11;

const int BTN_SERVO = A3;
const int BTN_STEP = A1;
const int BTN_CENTER = A5;

const int POT_PIN = A0;

const int STEP1_STEP = 5;
const int STEP1_DIR = 4;

const int STEP2_STEP = 7;
const int STEP2_DIR = 6;

Servo servoLeft;
Servo servoRight;

void rotateServo(int pins[], int values[], int count);
void smoothServo(int pins[], int values[], int count, int stepDelay);
void rotateStepper(int stepPins[], int dirPins[], int values[], int count);
void smoothStepper(int stepPins[], int dirPins[], int values[], int count, int stepDelay);
void setLeds(int pins[], int values[], int count);
bool readButton(int pin);
int readPotDeg();
int* makePins(int pin1, int pin2);
void demoSequence();

void setup() {
  Serial.begin(9600);
  
  pinMode(BTN_SERVO, INPUT);
  pinMode(BTN_STEP, INPUT);
  pinMode(BTN_CENTER, INPUT);
  
  pinMode(LED1, OUTPUT);
  pinMode(LED2, OUTPUT);
  pinMode(LED3, OUTPUT);
  pinMode(LED4, OUTPUT);
  
  pinMode(STEP1_STEP, OUTPUT);
  pinMode(STEP1_DIR, OUTPUT);
  pinMode(STEP2_STEP, OUTPUT);
  pinMode(STEP2_DIR, OUTPUT);

  servoLeft.attach(SERVO_LEFT_PIN);
  servoRight.attach(SERVO_RIGHT_PIN);
  
  demoSequence();
}

#define MODE_SERVO 0
#define MODE_STEPPER 1

const int LED_SERVO_L = 12;
const int LED_SERVO_R = 9;
const int LED_STEP_L = 10;
const int LED_STEP_R = 11;

int motorType = MODE_SERVO;
int mode = 1;
bool resetMode = false;
int lastPotAngle = 90;
unsigned long lastBlink = 0;
bool blinkState = false;

unsigned long lastPressServo = 0;
unsigned long lastPressStep = 0;
unsigned long lastPressCenter = 0;
const unsigned long debounceDelay = 250;

const float STEPS_PER_DEGREE = 1.0 / 1.8;
int currentStepsL = 0;
int currentStepsR = 0;
int targetStepsL = 0;
int targetStepsR = 0;
long lastStepTime = 0;
const int STEP_DELAY_US = 500;

void loop() {
  unsigned long now = millis();

  if (digitalRead(BTN_SERVO) == HIGH && now - lastPressServo > debounceDelay) {
    lastPressServo = now;
    resetMode = false;
    if (motorType != MODE_SERVO) {
      motorType = MODE_SERVO;
      mode = 1;
    } else {
      mode = (mode % 4) + 1;
    }
  }

  if (digitalRead(BTN_STEP) == HIGH && now - lastPressStep > debounceDelay) {
    lastPressStep = now;
    resetMode = false;
    if (motorType != MODE_STEPPER) {
      motorType = MODE_STEPPER;
      mode = 1;
    } else {
      mode = (mode % 4) + 1;
    }
  }

  if (digitalRead(BTN_CENTER) == HIGH && now - lastPressCenter > debounceDelay) {
    lastPressCenter = now;
    resetMode = true;
  }

  int potVal = analogRead(POT_PIN);
  int potDeg = map(potVal, 0, 1023, 0, 180);
  if (resetMode && abs(potDeg - 90) > 2) {
    resetMode = false;
  }
  if (!resetMode) {
    if (abs(potDeg - lastPotAngle) > 2) lastPotAngle = potDeg;
  }

  if (mode == 4 && now - lastBlink >= 100) {
    blinkState = !blinkState;
    lastBlink = now;
  }
  else if (mode != 4) {
    blinkState = true;
  }

  digitalWrite(LED_SERVO_L, (motorType == MODE_SERVO && (mode == 1 || mode == 2 || (mode == 4 && blinkState))) ? HIGH : LOW);
  digitalWrite(LED_SERVO_R, (motorType == MODE_SERVO && (mode == 1 || mode == 3 || (mode == 4 && blinkState))) ? HIGH : LOW);
  digitalWrite(LED_STEP_L, (motorType == MODE_STEPPER && (mode == 1 || mode == 2 || (mode == 4 && blinkState))) ? HIGH : LOW);
  digitalWrite(LED_STEP_R, (motorType == MODE_STEPPER && (mode == 1 || mode == 3 || (mode == 4 && blinkState))) ? HIGH : LOW);

  if (resetMode) {
    servoLeft.write(90);
    servoRight.write(90);

    if (currentStepsL != 0 || currentStepsR != 0) {
      int stepsToGoL = -currentStepsL;
      int stepsToGoR = -currentStepsR;
      
      digitalWrite(STEP1_DIR, (stepsToGoL > 0) ? HIGH : LOW);
      digitalWrite(STEP2_DIR, (stepsToGoR > 0) ? HIGH : LOW);
      
      int maxSteps = max(abs(stepsToGoL), abs(stepsToGoR));
      for (int i = 0; i < maxSteps; i++) {
        if (i < abs(stepsToGoL)) digitalWrite(STEP1_STEP, HIGH);
        if (i < abs(stepsToGoR)) digitalWrite(STEP2_STEP, HIGH);
        delayMicroseconds(STEP_DELAY_US);
        digitalWrite(STEP1_STEP, LOW);
        digitalWrite(STEP2_STEP, LOW);
        delayMicroseconds(STEP_DELAY_US);
      }
      currentStepsL = 0;
      currentStepsR = 0;
    }

    return;
  }

  int normalizedDeg = lastPotAngle - 90;
  int leftDeg = normalizedDeg;
  int rightDeg = normalizedDeg;

  if (mode == 2) {
    rightDeg = 0;
  } else if (mode == 3) {
    leftDeg = 0;
  } else if (mode == 4) {
    rightDeg = -normalizedDeg;
  }

  if (motorType == MODE_SERVO) {
    servoLeft.write(leftDeg + 90);
    servoRight.write(rightDeg + 90);
  }

  else if (motorType == MODE_STEPPER) {
    targetStepsL = round((float)leftDeg * 1440.0 / 90.0 );
    targetStepsR = round((float)rightDeg * 1440.0 / 90.0 );
    
    int deltaStepsL = targetStepsL - currentStepsL;
    int deltaStepsR = targetStepsR - currentStepsR;
    
    if (micros() - lastStepTime >= STEP_DELAY_US * 2) {
      lastStepTime = micros();
      
      bool stepped = false;
      
      if (deltaStepsL != 0) {
        digitalWrite(STEP1_DIR, (deltaStepsL > 0) ? HIGH : LOW);
        digitalWrite(STEP1_STEP, HIGH);
        stepped = true;
        if (deltaStepsL > 0) currentStepsL++;
        else currentStepsL--;
      }
      
      if (deltaStepsR != 0) {
        digitalWrite(STEP2_DIR, (deltaStepsR > 0) ? HIGH : LOW);
        digitalWrite(STEP2_STEP, HIGH);
        stepped = true;
        if (deltaStepsR > 0) currentStepsR++;
        else currentStepsR--;
      }
      
      if (stepped) {
        delayMicroseconds(STEP_DELAY_US);
        digitalWrite(STEP1_STEP, LOW);
        digitalWrite(STEP2_STEP, LOW);
      }
    }
  }
}

void demoSequence() {
  const unsigned long demoDuration = 6000UL;
  unsigned long startTime = millis();
  unsigned long lastBlink = 0;
  const unsigned long blinkInterval = 250;

  int leds[4] = {LED1, LED2, LED3, LED4}; 
  bool ledsState = false;

  const int SERVO_CENTER = 90;
  const int SERVO_LEFT = 0;
  const int SERVO_RIGHT = 180;
  int servoPos = SERVO_CENTER;
  int servoTarget = SERVO_LEFT;
  const int servoStep = 1;
  unsigned long lastServoMove = 0;
  const unsigned long servoInterval = 15;

  int stepPins[2] = {STEP1_STEP, STEP2_STEP};
  int dirPins[2] = {STEP1_DIR, STEP2_DIR};
  
  const int stepsPer90deg = 1440; 
  
  const unsigned long STEP_INTERVAL_MIN = 600;
  const unsigned long STEP_INTERVAL_MAX = 5000;
  const unsigned long STEP_ACCEL_RATE = 50;

  const int STEPS_P1 = stepsPer90deg;
  const int STEPS_P2 = stepsPer90deg * 2;
  const int STEPS_P3 = stepsPer90deg;
  
  const int ACCEL_STEPS = 100;

  int currentStep = 0;
  int demoPhase = 1; 
  int stepDir = LOW;
  unsigned long lastStepTime = 0;
  unsigned long stepInterval = STEP_INTERVAL_MAX;

  servoLeft.write(servoPos);
  servoRight.write(servoPos);
  for (int i = 0; i < 2; i++) {
    digitalWrite(dirPins[i], stepDir);
  }

  while (millis() - startTime < demoDuration) {
    unsigned long now = millis();

    if (now - lastBlink >= blinkInterval) {
      lastBlink = now;
      ledsState = !ledsState;
      for (int i = 0; i < 4; i++) digitalWrite(leds[i], ledsState);
    }

    if (now - lastServoMove >= servoInterval) {
      lastServoMove = now;
      
      if (servoPos < servoTarget) servoPos += servoStep;
      else if (servoPos > servoTarget) servoPos -= servoStep;
      
      servoLeft.write(servoPos);
      servoRight.write(servoPos);

      if (servoPos == servoTarget) {
        
        if (demoPhase == 1) { 
          servoTarget = SERVO_RIGHT;
          stepDir = HIGH;
          currentStep = 0;
          demoPhase = 2;
          stepInterval = STEP_INTERVAL_MAX;
        } else if (demoPhase == 2) { 
          servoTarget = SERVO_CENTER;
          stepDir = LOW;
          currentStep = 0;
          demoPhase = 3;
          stepInterval = STEP_INTERVAL_MAX;
        } else if (demoPhase == 3) {
          break;
        }
        
        for (int i = 0; i < 2; i++) {
          digitalWrite(dirPins[i], stepDir);
        }
      }
    }

    if (micros() - lastStepTime >= stepInterval) {
      int stepsToComplete = 0;
      if (demoPhase == 1) stepsToComplete = STEPS_P1;
      else if (demoPhase == 2) stepsToComplete = STEPS_P2;
      else if (demoPhase == 3) stepsToComplete = STEPS_P3;

      if (currentStep < stepsToComplete) {
        lastStepTime = micros();
        
        int stepsRemaining = stepsToComplete - currentStep;

        if (currentStep < ACCEL_STEPS) {
            if (stepInterval > STEP_INTERVAL_MIN) {
                stepInterval = max(STEP_INTERVAL_MIN, stepInterval - STEP_ACCEL_RATE);
            }
        } else if (stepsRemaining <= ACCEL_STEPS) {
            if (stepInterval < STEP_INTERVAL_MAX) {
                stepInterval = min(STEP_INTERVAL_MAX, stepInterval + STEP_ACCEL_RATE);
            }
        } else {
            stepInterval = STEP_INTERVAL_MIN;
        }

        for (int i = 0; i < 2; i++) {
          digitalWrite(stepPins[i], HIGH);
        }
        delayMicroseconds(200);
        for (int i = 0; i < 2; i++) {
          digitalWrite(stepPins[i], LOW);
        }
        currentStep++;
        
      }
    }
  }

  for (int i = 0; i < 4; i++) digitalWrite(leds[i], LOW);
  
  servoLeft.write(SERVO_CENTER);
  servoRight.write(SERVO_CENTER);
}

int* makePins(int pin1, int pin2) {
  static int arr[2];
  arr[0] = pin1;
  arr[1] = pin2;
  return arr;
}

void rotateServo(int pins[], int values[], int count) {
  for (int i = 0; i < count; i++) {
    Servo temp;
    temp.attach(pins[i]);
    temp.write(values[i]);
  }
}

void smoothServo(int pins[], int values[], int count, int stepDelay = 10) {
  for (int i = 0; i < count; i++) {
    Servo temp;
    temp.attach(pins[i]);
    int current = temp.read();
    int target = values[i];
    if (target > current) {
      for (int pos = current; pos <= target; pos++) {
        temp.write(pos);
        delay(stepDelay);
      }
    } else {
      for (int pos = current; pos >= target; pos--) {
        temp.write(pos);
        delay(stepDelay);
      }
    }
  }
}

void rotateStepper(int stepPins[], int dirPins[], int values[], int count) {
  for (int i = 0; i < count; i++) {
    int dir = (values[i] >= 0) ? HIGH : LOW;
    digitalWrite(dirPins[i], dir);
    for (int s = 0; s < abs(values[i]); s++) {
      digitalWrite(stepPins[i], HIGH);
      delayMicroseconds(500);
      digitalWrite(stepPins[i], LOW);
      delayMicroseconds(500);
    }
  }
}

void smoothStepper(int stepPins[], int dirPins[], int values[], int count, int stepDelay = 500) {
  for (int i = 0; i < count; i++) {
    int dir = (values[i] >= 0) ? HIGH : LOW;
    digitalWrite(dirPins[i], dir);
    for (int s = 0; s < abs(values[i]); s++) {
      digitalWrite(stepPins[i], HIGH);
      delayMicroseconds(stepDelay);
      digitalWrite(stepPins[i], LOW);
      delayMicroseconds(stepDelay);
    }
  }
}

void setLeds(int pins[], int values[], int count) {
  for (int i = 0; i < count; i++) {
    digitalWrite(pins[i], values[i]);
  }
}

bool readButton(int pin) {
  return digitalRead(pin) == LOW;
}

int readPotDeg() {
  int val = analogRead(POT_PIN);
  return map(val, 0, 1023, 0, 180);
}